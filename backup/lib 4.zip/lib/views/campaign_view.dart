import 'dart:async';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import 'package:digital_signage/models/compaign_model.dart';

import '../view_models/mqtt_view_model.dart';
import '../views/no_content_view.dart';
import '../widgets/center_image_widget.dart';
import '../widgets/text_widget.dart';

class CampaignView extends StatefulWidget {
  const CampaignView({super.key});

  @override
  State<CampaignView> createState() => _CampaignViewState();
}

class _CampaignViewState extends State<CampaignView> {
  late FocusNode _focusNode;
  Timer? _restrictionCheckTimer;

  @override
  void initState() {
    super.initState();
    _focusNode = FocusNode();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final mqttViewModel = Provider.of<MqttViewModel>(context, listen: false);
      mqttViewModel.startPlaylistTimerForCampaign();
    });
    // Check restrictions every 8 seconds to handle time-based restrictions
    _restrictionCheckTimer =
        Timer.periodic(const Duration(seconds: 8), (timer) {
      if (mounted) {
        setState(() {
          // Trigger rebuild to re-check restrictions
        });
      } else {
        timer.cancel();
      }
    });
  }

  @override
  void dispose() {
    _restrictionCheckTimer?.cancel();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // IMPORTANT: must listen to ViewModel changes so UI updates immediately
    // when new MQTT publish_campaign data arrives.
    final mqttViewModel = Provider.of<MqttViewModel>(context);
    final campaignModel = mqttViewModel.campaignModel;

    if (campaignModel?.data?.playerCampaigns?.isEmpty ?? true) {
      return const NoContentView();
    }

    final campaign = campaignModel
        ?.data?.playerCampaigns?[mqttViewModel.currentIndexOfCapmaign];
    if (campaign == null) {
      return const NoContentView();
    }

    final campaignSchedule = campaign.campaignSchedule;

    // ANSI color codes for colorful logs
    const String reset = '\x1B[0m';
    const String red = '\x1B[31m';
    const String green = '\x1B[32m';
    const String yellow = '\x1B[33m';
    const String blue = '\x1B[34m';
    const String cyan = '\x1B[36m';

    print(
        '$cyan═══════════════════════════════════════════════════════════$reset');
    print('$cyan🎬 CAMPAIGN RESTRICTION CHECK$reset');
    print(
        '$cyan═══════════════════════════════════════════════════════════$reset');
    print('$blue📋 Campaign: ${campaign.campaignName ?? "N/A"}$reset');

    // Step 1: Check campaign restrictions first
    bool campaignCanPlay = false;

    if (campaignSchedule?.alwaysPlay ?? false) {
      campaignCanPlay = true;
      print('$green✅ CAMPAIGN: alwaysPlay = true → Campaign can play$reset');
    } else {
      // Check campaign restrictions
      final restrictions = campaignSchedule?.restrictions;
      if (restrictions != null && restrictions.isNotEmpty) {
        print(
            '$yellow🔍 CAMPAIGN: Checking ${restrictions.length} restriction(s)...$reset');
        campaignCanPlay = mqttViewModel.checkRestrictions(restrictions);
        if (campaignCanPlay) {
          print(
              '$green✅ CAMPAIGN: Restrictions PASSED → Campaign can play$reset');
        } else {
          print(
              '$red❌ CAMPAIGN: Restrictions FAILED → Campaign cannot play$reset');
        }
      } else {
        print('$yellow⚠️  CAMPAIGN: No restrictions configured$reset');
        campaignCanPlay = false; // No restrictions means don't play
      }
    }

    print(
        '$cyan═══════════════════════════════════════════════════════════$reset');

    if (campaignCanPlay) {
      return _buildZones(campaign, campaignCanPlay);
    } else {
      // Show "not scheduled" screen with same background as other screens
      return Scaffold(
        body: Stack(
          children: [
            // Background image (same as other screens)
            Image.asset(
              "assets/images/background.png",
              fit: BoxFit.cover,
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
            ),
            // Centered message
            const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomImageWidget(
                    imagePath: 'assets/images/Browser.png',
                  ),
                  SimpleText(
                    text: "Campaign Not Scheduled",
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                  SimpleText(
                    text: "Campaign is not scheduled to play at this time.",
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
  }

  Widget _buildZones(PlayerCampaign campaign, bool campaignCanPlay) {
    // Get device screen size
    final screenSize = MediaQuery.of(context).size;
    final deviceWidth = screenSize.width;
    final deviceHeight = screenSize.height;

    // Get campaign resolution
    final campaignWidth = campaign.resolution?.width?.toDouble() ?? deviceWidth;
    final campaignHeight =
        campaign.resolution?.height?.toDouble() ?? deviceHeight;

    // Calculate scaling factors
    final scaleX = deviceWidth / campaignWidth;
    final scaleY = deviceHeight / campaignHeight;

    print("Campaign resolution: ${campaignWidth}x${campaignHeight}");
    print("Device resolution: ${deviceWidth}x${deviceHeight}");
    print("Scale factors: X=$scaleX, Y=$scaleY");

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: (details) {
          final mqttViewModel =
              Provider.of<MqttViewModel>(context, listen: false);
          mqttViewModel.setTapPosition(
              details.localPosition.dx, details.localPosition.dy);
          print(
              "Tapped at: x=${details.localPosition.dx}, y=${details.localPosition.dy}");
        },
        child: Stack(
          children: (campaign.zones ?? []).map((zone) {
            final scaledX = (zone.x ?? 0) * scaleX;
            final scaledY = (zone.y ?? 0) * scaleY;
            final scaledWidth = (zone.width ?? 0) * scaleX;
            final scaledHeight = (zone.height ?? 0) * scaleY;

            return Positioned(
              left: scaledX,
              top: scaledY,
              width: scaledWidth,
              height: scaledHeight,
              child: VideoPlaylistWidget(
                zoneId: (zone.id ?? 0).toString(),
                mediaItems: zone.mediaItems ?? [],
                campaignCanPlay: campaignCanPlay,
                campaignSchedule: campaign.campaignSchedule,
                coordinateBaseWidth: campaignWidth,
                coordinateBaseHeight: campaignHeight,
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class VideoPlaylistWidget extends StatefulWidget {
  final String zoneId;
  final List<MediaItem> mediaItems;
  final bool campaignCanPlay;
  final CampaignSchedule? campaignSchedule;

  /// Coordinate system base for (x,y,width,height) in zones (usually campaign resolution).
  final double coordinateBaseWidth;
  final double coordinateBaseHeight;

  const VideoPlaylistWidget({
    super.key,
    required this.zoneId,
    required this.mediaItems,
    required this.campaignCanPlay,
    required this.campaignSchedule,
    required this.coordinateBaseWidth,
    required this.coordinateBaseHeight,
  });

  @override
  _VideoPlaylistWidgetState createState() => _VideoPlaylistWidgetState();
}

class _VideoPlaylistWidgetState extends State<VideoPlaylistWidget> {
  int _currentMediaIndex = 0;
  Timer? _timer;
  Timer? _restrictionCheckTimer;
  double _opacity = 1.0;
  VideoPlayerController? _videoController;
  DateTime? _videoStartTime;
  int? _targetDuration;

  @override
  void initState() {
    super.initState();
    _timer = Timer(Duration.zero, () {});
    _startRestrictionCheckTimer();
    _initializeNextMedia();
  }

  void _startRestrictionCheckTimer() {
    // Check campaign restrictions every 8 seconds
    _restrictionCheckTimer?.cancel();
    _restrictionCheckTimer =
        Timer.periodic(const Duration(seconds: 8), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      _checkCampaignRestrictions();
    });
  }

  void _checkCampaignRestrictions() {
    if (widget.campaignSchedule == null) return;

    final mqttViewModel = Provider.of<MqttViewModel>(context, listen: false);
    const String reset = '\x1B[0m';
    const String red = '\x1B[31m';
    const String yellow = '\x1B[33m';
    const String cyan = '\x1B[36m';

    bool canPlay = false;

    if (widget.campaignSchedule?.alwaysPlay ?? false) {
      canPlay = true;
    } else {
      final restrictions = widget.campaignSchedule?.restrictions;
      if (restrictions != null && restrictions.isNotEmpty) {
        canPlay = mqttViewModel.checkRestrictions(restrictions);
      } else {
        canPlay = false;
      }
    }

    // If campaign can no longer play, stop media
    if (!canPlay && widget.campaignCanPlay) {
      print(
          '$red🛑 PERIODIC CHECK: Campaign restrictions FAILED → Stopping media$reset');
      print(
          '$yellow⏸️  Media was playing but campaign restrictions no longer allow it$reset');
      _stopMedia();
    } else if (canPlay && !widget.campaignCanPlay) {
      print(
          '$cyan✅ PERIODIC CHECK: Campaign restrictions now PASS → Can resume media$reset');
      // Note: We can't automatically resume here as widget.campaignCanPlay is read-only
      // The parent widget needs to rebuild with new campaignCanPlay value
    }
  }

  void _stopMedia() {
    _timer?.cancel();
    _videoController?.pause();
    _videoController?.removeListener(_checkVideoPlaybackDuration);
    setState(() {
      _opacity = 0.0;
    });
  }

  @override
  void didUpdateWidget(covariant VideoPlaylistWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.mediaItems != widget.mediaItems ||
        oldWidget.zoneId != widget.zoneId ||
        oldWidget.campaignCanPlay != widget.campaignCanPlay) {
      // If campaign can no longer play, reset state
      if (!widget.campaignCanPlay && oldWidget.campaignCanPlay) {
        print(
            '\x1B[31m🛑 Campaign restrictions changed - stopping media\x1B[0m');
      }
      _resetState();
    }
  }

  void _resetState() {
    _currentMediaIndex = 0;
    _timer?.cancel();
    _videoController?.removeListener(_checkVideoPlaybackDuration);
    _videoController?.dispose();
    _videoController = null;
    _videoStartTime = null;
    _targetDuration = null;
    setState(() {
      _opacity = 1.0;
    });
    _initializeNextMedia();
  }

  bool _isNestedCampaign(MediaItem media) {
    final type = (media.mediaType ?? '').toLowerCase();
    return (media.zones != null && media.zones!.isNotEmpty) ||
        type == 'campaign';
  }

  Widget _buildNestedZones(MediaItem media) {
    final zones = media.zones ?? const <CampaignZone>[];
    if (zones.isEmpty) {
      return Center(child: Text("Zone ${widget.zoneId}: No subzones."));
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final scaleX = constraints.maxWidth / widget.coordinateBaseWidth;
        final scaleY = constraints.maxHeight / widget.coordinateBaseHeight;

        return ClipRect(
          child: Stack(
            fit: StackFit.expand,
            children: zones.map((z) {
              final left = (z.x ?? 0) * scaleX;
              final top = (z.y ?? 0) * scaleY;
              final width = (z.width ?? 0) * scaleX;
              final height = (z.height ?? 0) * scaleY;

              return Positioned(
                left: left,
                top: top,
                width: width,
                height: height,
                child: VideoPlaylistWidget(
                  zoneId: '${widget.zoneId}.${z.id ?? 0}',
                  mediaItems: z.mediaItems ?? const <MediaItem>[],
                  campaignCanPlay: widget.campaignCanPlay,
                  campaignSchedule: widget.campaignSchedule,
                  coordinateBaseWidth: widget.coordinateBaseWidth,
                  coordinateBaseHeight: widget.coordinateBaseHeight,
                ),
              );
            }).toList(),
          ),
        );
      },
    );
  }

  void _initializeNextMedia() {
    if (widget.mediaItems.isEmpty) {
      print("Zone ${widget.zoneId}: No media items available.");
      return;
    }

    // Ensure _currentMediaIndex is within bounds
    if (_currentMediaIndex < 0 ||
        _currentMediaIndex >= widget.mediaItems.length) {
      print(
          "Zone ${widget.zoneId}: Media index $_currentMediaIndex is out of bounds (0-${widget.mediaItems.length - 1}), resetting to 0");
      _currentMediaIndex = 0;
    }

    // ANSI color codes for colorful logs
    const String reset = '\x1B[0m';
    const String red = '\x1B[31m';
    const String green = '\x1B[32m';
    const String yellow = '\x1B[33m';
    const String blue = '\x1B[34m';
    const String magenta = '\x1B[35m';
    const String cyan = '\x1B[36m';

    MediaItem currentMedia = widget.mediaItems[_currentMediaIndex];

    print(
        '$magenta═══════════════════════════════════════════════════════════$reset');
    print('$magenta🎥 MEDIA RESTRICTION CHECK$reset');
    print(
        '$magenta═══════════════════════════════════════════════════════════$reset');
    print('$blue📍 Zone: ${widget.zoneId}$reset');
    print('$blue🎬 Media ID: ${currentMedia.id ?? "N/A"}$reset');
    print('$blue📁 Media URL: ${currentMedia.mediaUrl ?? "N/A"}$reset');
    print(
        '$cyan📊 Campaign can play: ${widget.campaignCanPlay ? "YES ✅" : "NO ❌"}$reset');

    // CRITICAL: Campaign restrictions must pass first!
    if (!widget.campaignCanPlay) {
      print(
          '$red❌ MEDIA: Campaign restrictions FAILED → Media cannot play$reset');
      print('$red⏭️  MEDIA: Skipping media (campaign not allowed)$reset');
      print(
          '$magenta═══════════════════════════════════════════════════════════$reset');
      _onMediaEnd();
      return;
    }

    // Now check media-level restrictions
    bool shouldPlay = false;
    final mqttViewModel = Provider.of<MqttViewModel>(context, listen: false);

    // Step 1: Check media alwaysPlay
    if (currentMedia.schedule?.alwaysPlay ?? false) {
      shouldPlay = true;
      print('$green✅ MEDIA: alwaysPlay = true → Media can play$reset');
    } else {
      // Step 2: Check media restrictions (if any)
      final restrictions = currentMedia.schedule?.restrictions;
      if (restrictions != null && restrictions.isNotEmpty) {
        print(
            '$yellow🔍 MEDIA: Checking ${restrictions.length} restriction(s)...$reset');
        shouldPlay = mqttViewModel.checkRestrictions(restrictions);
        if (shouldPlay) {
          print('$green✅ MEDIA: Restrictions PASSED → Media can play$reset');
        } else {
          print('$red❌ MEDIA: Restrictions FAILED → Media cannot play$reset');
        }
      } else {
        print(
            '$yellow⚠️  MEDIA: No restrictions configured and alwaysPlay = false$reset');
        print('$red⏭️  MEDIA: Skipping media (no schedule configured)$reset');
        print(
            '$magenta═══════════════════════════════════════════════════════════$reset');
        _onMediaEnd();
        return;
      }
    }

    print(
        '$magenta═══════════════════════════════════════════════════════════$reset');

    if (shouldPlay) {
      // Duration is already an int in the model, convert to string for _startMediaLoop
      int? durationInt = currentMedia.settings?.duration;
      String duration = (durationInt ?? 0).toString();
      print(
          '$green▶️  MEDIA: Loading and playing media (duration: $duration seconds)$reset');
      _startMediaLoop(duration);
      // Nested campaign media has no direct URL to load; it renders subzones instead.
      if (_isNestedCampaign(currentMedia)) {
        setState(() {});
        return;
      }
      _loadMedia(currentMedia);
    } else {
      print('$red⏭️  MEDIA: Skipping media (restrictions did not pass)$reset');
      _onMediaEnd();
    }
  }

  void _startMediaLoop(String duration) {
    print("Starting media loop for duration: $duration");
    int durationSeconds = int.tryParse(duration) ?? 10;

    // Cancel any existing timer
    _timer?.cancel();

    // Only set timer if duration is greater than 0
    if (durationSeconds > 0) {
      _timer = Timer(Duration(seconds: durationSeconds), () {
        print(
            "[LOG] Media duration timer expired after $durationSeconds seconds");
        _onMediaEnd();
      });
    }
  }

  void _loadMedia(MediaItem nextMedia) {
    final mediaUrl = nextMedia.mediaUrl ?? '';
    print("[LOG] Loading media: $mediaUrl");
    if (mediaUrl.isEmpty) {
      print("[LOG] Media URL is empty, skipping");
      _onMediaEnd();
      return;
    }

    if (isVideoFile(mediaUrl)) {
      _initializeNextVideo(nextMedia);
    } else if (isWebFile(mediaUrl)) {
      // Ensure you are not reinitializing the WebView if the file is the same
      if (_currentMediaIndex > 0 &&
          (widget.mediaItems[_currentMediaIndex - 1].mediaUrl ?? '') ==
              mediaUrl) {
        print("[LOG] Skipping recreation of the same WebView");
        return;
      }
      // HTML files use the timer from _startMediaLoop, no additional timer needed
      setState(() {});
    } else if (isSvgContent(mediaUrl)) {
      print("[LOG] Current media is SVG: ${nextMedia.mediaUrl}");
      // SVG content uses the timer from _startMediaLoop, no additional timer needed
      setState(() {});
    } else {
      print("[LOG] Current media is an image: ${nextMedia.mediaUrl}");
      // Images use the timer from _startMediaLoop, no additional timer needed
      setState(() {});
    }
  }

  void _initializeNextVideo(MediaItem nextMedia) {
    final mediaUrl = nextMedia.mediaUrl ?? '';
    if (mediaUrl.isEmpty) {
      print("[LOG] Video URL is empty, skipping");
      _onMediaEnd();
      return;
    }
    print("[LOG] Initializing video: $mediaUrl");

    // Get volume from settings (0-100, convert to 0.0-1.0)
    final volume = (nextMedia.settings?.volume ?? 100) / 100.0;
    print(
        "[LOG] Setting video volume to: $volume (${nextMedia.settings?.volume}%)");

    _videoController = VideoPlayerController.file(File(mediaUrl))
      ..initialize().then((_) {
        if (_videoController!.value.isInitialized) {
          int targetDuration = nextMedia.settings?.duration ??
              _videoController!.value.duration.inSeconds;
          int videoLength = _videoController!.value.duration.inSeconds;

          _targetDuration = targetDuration;
          _videoStartTime = DateTime.now();

          print("Target play duration: $targetDuration seconds");
          print("Video length: $videoLength seconds");

          setState(() {
            _videoController!.setVolume(volume.clamp(0.0, 1.0));
            _videoController!.play();

            // If video is shorter than target duration, loop it
            if (targetDuration > 0 &&
                videoLength > 0 &&
                videoLength < targetDuration) {
              _videoController!.setLooping(true);
              print(
                  "[LOG] Video ($videoLength sec) is shorter than target duration ($targetDuration sec), will loop");
            } else {
              _videoController!.setLooping(false);
            }
          });

          // Don't set timer here - it's already set in _startMediaLoop
          // Only add listener for safety check (if video ends naturally before timer)
          if (targetDuration > 0) {
            // Add listener to check if video ends naturally before timer expires
            _videoController!.addListener(_checkVideoPlaybackDuration);
          } else {
            // If no duration specified, let video play until end
            _videoController!.addListener(() {
              if (_videoController!.value.position >=
                      _videoController!.value.duration &&
                  _videoController!.value.position.inMilliseconds > 0) {
                print("[LOG] Video ended naturally, transitioning");
                _videoController!.removeListener(() {});
                _onMediaEnd();
              }
            });
          }
        }
      }).catchError((error) {
        print("[LOG] Error initializing video: $error");
        print("[LOG] Video URL: ${nextMedia.mediaUrl}");
        setState(() {});
      });
  }

  void _checkVideoPlaybackDuration() {
    if (_videoController == null ||
        _videoStartTime == null ||
        _targetDuration == null) {
      return;
    }

    // Safety check: Only transition if timer hasn't already fired
    // This prevents double transitions when both timer and listener fire
    if (_timer?.isActive ?? false) {
      final elapsed = DateTime.now().difference(_videoStartTime!).inSeconds;
      // Only transition if we're past the target duration AND timer is still active
      // This handles edge cases where video might end naturally before timer
      if (elapsed >= _targetDuration! &&
          _videoController!.value.position >=
              _videoController!.value.duration) {
        print("[LOG] Video ended naturally before timer, transitioning early");
        _videoController!.removeListener(_checkVideoPlaybackDuration);
        _timer?.cancel(); // Cancel timer since we're transitioning now
        _videoController!.pause();
        _onMediaEnd();
      }
    }
  }

  bool _isDisposed = false;

  void _onMediaEnd() {
    // Cancel any active timers
    _timer?.cancel();

    // Remove video listener
    if (_videoController != null) {
      _videoController!.removeListener(_checkVideoPlaybackDuration);
    }

    if (!_isDisposed && mounted) {
      // Dispose current video controller before transitioning
      _videoController?.pause();
      _videoController?.dispose();
      _videoController = null;
      _videoStartTime = null;
      _targetDuration = null;

      final currentIndex = _currentMediaIndex;
      final totalMedia = widget.mediaItems.length;
      print("[LOG] Media ended at index $currentIndex of $totalMedia");

      setState(() {
        _opacity = 0.0;
      });

      // Wait for fade out transition, then move to next media
      Future.delayed(const Duration(milliseconds: 500), () {
        if (!mounted || _isDisposed) return;

        // Check if mediaItems list is empty
        if (widget.mediaItems.isEmpty) {
          print("[LOG] No media items available, cannot transition");
          return;
        }

        setState(() {
          if (_currentMediaIndex < widget.mediaItems.length - 1) {
            _currentMediaIndex++;
          } else {
            _currentMediaIndex = 0; // Loop back to first media
          }
          print(
              "[LOG] Transitioning to media index $_currentMediaIndex of ${widget.mediaItems.length}");

          // Safely access media items only if list is not empty
          if (_currentMediaIndex < widget.mediaItems.length) {
            print(
                "[LOG] Next media ID: ${widget.mediaItems[_currentMediaIndex].id ?? 'N/A'}");
            print(
                "[LOG] Next media URL: ${widget.mediaItems[_currentMediaIndex].mediaUrl ?? 'N/A'}");
          }

          _opacity = 1.0;
          _initializeNextMedia();
        });
      });
    }
  }

  bool isWebFile(String path) {
    final webExtensions = ['.html'];
    return webExtensions.any((ext) => path.endsWith(ext));
  }

  bool isSvgContent(String content) {
    // Check if content is SVG code (starts with <svg or contains <svg tag)
    final trimmed = content.trim();
    return trimmed.startsWith('<svg') ||
        (trimmed.contains('<svg') && trimmed.contains('</svg>'));
  }

  String _decodeSvgContent(String content) {
    // Decode URL-encoded SVG content if needed
    try {
      // Try URL decoding first
      final decoded = Uri.decodeComponent(content);
      // If decoding changed something and it's still valid SVG, use decoded version
      if (decoded != content && isSvgContent(decoded)) {
        return decoded;
      }
      // If already valid SVG, return as-is
      if (isSvgContent(content)) {
        return content;
      }
      // If not SVG after decoding, return original
      return content;
    } catch (e) {
      // If decoding fails, return original content
      print("[LOG] SVG decode error: $e");
      return content;
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _restrictionCheckTimer?.cancel();
    _isDisposed = true;
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.mediaItems.isEmpty) {
      return Center(child: Text("Zone ${widget.zoneId}: No media items."));
    }

    // Ensure _currentMediaIndex is within bounds
    if (_currentMediaIndex < 0 ||
        _currentMediaIndex >= widget.mediaItems.length) {
      _currentMediaIndex = 0; // Reset to first item if out of bounds
    }

    MediaItem currentMedia = widget.mediaItems[_currentMediaIndex];
    return AnimatedOpacity(
      opacity: _opacity,
      duration: const Duration(milliseconds: 500),
      child: AnimatedSwitcher(
        key: ValueKey(currentMedia.id),
        duration: const Duration(milliseconds: 500),
        transitionBuilder: (child, animation) {
          print(
              "this is transition${currentMedia.settings?.transition ?? 'none'}");

          switch (currentMedia.settings?.transition ?? 'none') {
            case "fadeIn":
              return FadeTransition(opacity: animation, child: child);
            case "slideOverLeftToRight":
              return SlideTransition(
                position: animation.drive(
                  Tween(
                    begin: const Offset(-1, 0), // From left
                    end: Offset.zero,
                  ).chain(CurveTween(curve: Curves.easeInOut)),
                ),
                child: child,
              );
            case "slideOverRightToLeft":
              return SlideTransition(
                position: animation.drive(
                  Tween(
                    begin: const Offset(1, 0),
                    end: Offset.zero,
                  ).chain(CurveTween(curve: Curves.easeInOut)),
                ),
                child: child,
              );
            case "slideOverTopToBottom":
              return SlideTransition(
                position: animation.drive(
                  Tween(
                    begin: const Offset(0, -1), // From top
                    end: Offset.zero,
                  ).chain(CurveTween(curve: Curves.easeInOut)),
                ),
                child: child,
              );
            case "slideOverBottomToTop":
              return SlideTransition(
                position: animation.drive(
                  Tween(
                    begin: const Offset(0, 1), // From bottom
                    end: Offset.zero,
                  ).chain(CurveTween(curve: Curves.easeInOut)),
                ),
                child: child,
              );
            case "slideInOutLeftToRight":
              return Stack(
                children: [
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: const Offset(-1, 0), // From left
                        end: Offset.zero,
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: Offset.zero,
                        end: const Offset(1, 0), // Slide out to right
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                ],
              );
            case "slideInOutRightToLeft":
              return Stack(
                children: [
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: const Offset(1, 0), // From right
                        end: Offset.zero,
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: Offset.zero,
                        end: const Offset(-1, 0), // Slide out to left
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                ],
              );
            case "slideInOutTopToBottom":
              return Stack(
                children: [
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: const Offset(0, -1), // From top
                        end: Offset.zero,
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: Offset.zero,
                        end: const Offset(0, 1), // Slide out to bottom
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                ],
              );
            case "slideInOutBottomToTop":
              return Stack(
                children: [
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: const Offset(0, 1), // From bottom
                        end: Offset.zero,
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: Offset.zero,
                        end: const Offset(0, -1), // Slide out to top
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                ],
              );
            default:
              return child; // No transition applied
          }
        },
        child: _isNestedCampaign(currentMedia)
            ? _buildNestedZones(currentMedia)
            : isVideoFile(currentMedia.mediaUrl ?? '')
                ? VideoPlayerWidget(
                    key: ValueKey(
                        '${currentMedia.id ?? ''}_${_currentMediaIndex}'),
                    filePath: currentMedia.mediaUrl ?? '',
                    onVideoEnd: () {
                      // Only call _onMediaEnd if timer is not active (already fired or no duration set)
                      // This prevents double transitions when video ends naturally
                      if (!(_timer?.isActive ?? false)) {
                        print(
                            "[LOG] Video ended naturally, timer already expired or not set");
                        _onMediaEnd();
                      } else {
                        print(
                            "[LOG] Video ended naturally but timer is still active, waiting for timer");
                      }
                    },
                    transitionType: currentMedia.settings?.transition ?? 'none',
                    volume: (currentMedia.settings?.volume ?? 100) / 100.0,
                  )
                : isWebFile(currentMedia.mediaUrl ?? '')
                    ? WBViewWidget(
                        key: ValueKey(currentMedia.id ?? ''),
                        media: currentMedia.mediaUrl ?? '',
                        onMediaEnd: _onMediaEnd)
                    : isSvgContent(currentMedia.mediaUrl ?? '')
                        ? SvgWidget(
                            key: ValueKey(currentMedia.id ?? ''),
                            svgContent: _decodeSvgContent(currentMedia.mediaUrl ?? ''),
                            onSvgEnd: _onMediaEnd,
                            transitionType:
                                currentMedia.settings?.transition ?? 'none',
                          )
                        : ImageWidget(
                            key: ValueKey(currentMedia.id ?? ''),
                            filePath: currentMedia.mediaUrl ?? '',
                            onImageEnd: _onMediaEnd,
                            transitionType:
                                currentMedia.settings?.transition ?? 'none',
                          ),
      ),
    );
  }

  bool isVideoFile(String path) {
    final videoExtensions = ['.mp4', '.avi', '.mov', '.mkv'];
    return videoExtensions.any((ext) => path.endsWith(ext));
  }
}

class VideoPlayerWidget extends StatefulWidget {
  final String filePath;
  final VoidCallback onVideoEnd;
  final String transitionType;
  final double volume;

  const VideoPlayerWidget({
    super.key,
    required this.filePath,
    required this.onVideoEnd,
    required this.transitionType,
    this.volume = 1.0,
  });

  @override
  _VideoPlayerWidgetState createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _controller;
  bool _isLoading = true;
  bool _isVideoEnded = false;

  @override
  void initState() {
    super.initState();
    _initializeVideo();
  }

  void _initializeVideo() async {
    print("[LOG] VideoPlayerWidget: Initializing video: ${widget.filePath}");

    // Check if file exists
    final file = File(widget.filePath);
    if (!await file.exists()) {
      print(
          "[LOG] VideoPlayerWidget: ERROR - File does not exist: ${widget.filePath}");
      setState(() {
        _isLoading = false;
      });
      return;
    }

    print("[LOG] VideoPlayerWidget: File exists, creating controller...");
    _controller = VideoPlayerController.file(file)
      ..initialize().then(
        (_) {
          print("[LOG] VideoPlayerWidget: Video initialized successfully");
          print(
              "[LOG] VideoPlayerWidget: Duration: ${_controller.value.duration}");
          print("[LOG] VideoPlayerWidget: Size: ${_controller.value.size}");
          print(
              "[LOG] VideoPlayerWidget: IsInitialized: ${_controller.value.isInitialized}");

          if (!_controller.value.isInitialized) {
            print(
                "[LOG] VideoPlayerWidget: ERROR - Controller not initialized after initialize()");
            setState(() {
              _isLoading = false;
            });
            return;
          }

          setState(
            () {
              _isLoading = false;
              _controller.setVolume(widget.volume.clamp(0.0, 1.0));
              // Keep videos playing continuously (repeat forever).
              _controller.setLooping(true);
              _controller.play();
              print("[LOG] VideoPlayerWidget: Video play() called");
            },
          );

          // Verify video is playing after a short delay
          Future.delayed(const Duration(milliseconds: 500), () {
            if (mounted) {
              print(
                  "[LOG] VideoPlayerWidget: After 500ms - IsPlaying: ${_controller.value.isPlaying}, "
                  "HasError: ${_controller.value.hasError}, "
                  "Position: ${_controller.value.position}");
              if (_controller.value.hasError) {
                print(
                    "[LOG] VideoPlayerWidget: ERROR after play() - ${_controller.value.errorDescription}");
              }
              if (!_controller.value.isPlaying &&
                  _controller.value.isInitialized) {
                print(
                    "[LOG] VideoPlayerWidget: WARNING - Video not playing after play() call, trying again...");
                _controller.play();
              }
            }
          });

          _controller.addListener(
            () {
              // If looping is enabled, never treat "reached end" as a terminal state.
              // Otherwise, reaching the end means the media is done.
              if (!_controller.value.isLooping &&
                  _controller.value.position >= _controller.value.duration &&
                  !_isVideoEnded) {
                _isVideoEnded = true;
                widget.onVideoEnd();
              }

              // Log playback state periodically
              if (_controller.value.position.inSeconds % 5 == 0 &&
                  _controller.value.position.inMilliseconds > 0) {
                print(
                    "[LOG] VideoPlayerWidget: Playing - Position: ${_controller.value.position}, "
                    "IsPlaying: ${_controller.value.isPlaying}, "
                    "HasError: ${_controller.value.hasError}");
                if (_controller.value.hasError) {
                  print(
                      "[LOG] VideoPlayerWidget: ERROR - ${_controller.value.errorDescription}");
                }
              }
            },
          );
        },
      ).catchError(
        (error, stackTrace) {
          print("[LOG] VideoPlayerWidget: ERROR initializing video: $error");
          print("[LOG] VideoPlayerWidget: Stack trace: $stackTrace");
          print("[LOG] VideoPlayerWidget: File path: ${widget.filePath}");
          setState(
            () {
              _isLoading = false;
            },
          );
        },
      );
  }

  void _checkVideoEnd() {
    if (_controller.value.isInitialized &&
        !_controller.value.isPlaying &&
        _controller.value.position >= _controller.value.duration &&
        !_isVideoEnded) {
      setState(() {
        _isVideoEnded = true;
      });
      widget.onVideoEnd();
    }
  }

  @override
  void didUpdateWidget(covariant VideoPlayerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.filePath != widget.filePath) {
      _controller.removeListener(_checkVideoEnd);
      _controller.dispose();
      _initializeVideo();
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget videoWidget;

    if (_isLoading) {
      print("[LOG] VideoPlayerWidget: Building - Still loading...");
      videoWidget = const Center(child: CircularProgressIndicator());
    } else if (!_controller.value.isInitialized) {
      print("[LOG] VideoPlayerWidget: Building - Controller not initialized!");
      videoWidget = Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error, size: 48, color: Colors.red),
            const SizedBox(height: 16),
            Text("Video not initialized", style: TextStyle(fontSize: 16)),
            Text("File: ${widget.filePath}", style: TextStyle(fontSize: 12)),
            if (_controller.value.hasError)
              Text("Error: ${_controller.value.errorDescription}",
                  style: TextStyle(fontSize: 12, color: Colors.red)),
          ],
        ),
      );
    } else {
      print("[LOG] VideoPlayerWidget: Building - Displaying video player");
      print(
          "[LOG] VideoPlayerWidget: IsPlaying: ${_controller.value.isPlaying}");
      print("[LOG] VideoPlayerWidget: HasError: ${_controller.value.hasError}");
      if (_controller.value.hasError) {
        print(
            "[LOG] VideoPlayerWidget: ERROR - ${_controller.value.errorDescription}");
      }

      videoWidget = SizedBox.expand(
        child: VideoPlayer(_controller),
      );
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: videoWidget,
    );
  }

  @override
  void dispose() {
    _controller.removeListener(_checkVideoEnd);
    _controller.dispose();
    super.dispose();
  }
}

class ImageWidget extends StatelessWidget {
  final String filePath;
  final VoidCallback onImageEnd;

  final String transitionType;

  const ImageWidget({
    super.key,
    required this.filePath,
    required this.onImageEnd,
    required this.transitionType,
  });

  @override
  Widget build(BuildContext context) {
    Widget imageWidget = SizedBox.expand(
      child: Image.file(
        File(filePath),
        fit: BoxFit.cover,
        height: MediaQuery.sizeOf(context).height,
        width: MediaQuery.sizeOf(context).width,
      ),
    );

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: imageWidget,
    );
  }
}

class SvgWidget extends StatefulWidget {
  final String svgContent;
  final VoidCallback onSvgEnd;
  final String transitionType;

  const SvgWidget({
    super.key,
    required this.svgContent,
    required this.onSvgEnd,
    required this.transitionType,
  });

  @override
  _SvgWidgetState createState() => _SvgWidgetState();
}

class _SvgWidgetState extends State<SvgWidget> {
  InAppWebViewController? _webViewController;
  double progress = 0;

  @override
  void dispose() {
    _webViewController?.dispose();
    super.dispose();
  }

  String _createSvgHtml(String svgContent) {
    // Create an HTML page that centers and scales the SVG to fill the viewport
    return '''
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    html, body {
      width: 100%;
      height: 100%;
      overflow: hidden;
      background: transparent;
    }
    body {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    svg {
      width: 100%;
      height: 100%;
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }
  </style>
</head>
<body>
  $svgContent
</body>
</html>
''';
  }

  @override
  Widget build(BuildContext context) {
    // Create HTML content with SVG embedded
    final htmlContent = _createSvgHtml(widget.svgContent);

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: Column(
        children: [
          if (progress < 1.0) LinearProgressIndicator(value: progress),
          Expanded(
            child: InAppWebView(
              initialData: InAppWebViewInitialData(
                data: htmlContent,
                mimeType: 'text/html',
                encoding: 'utf-8',
              ),
              initialSettings: InAppWebViewSettings(
                transparentBackground: true,
                useShouldOverrideUrlLoading: true,
                javaScriptEnabled: true,
                domStorageEnabled: true,
              ),
              onWebViewCreated: (InAppWebViewController controller) {
                _webViewController = controller;
              },
              onProgressChanged:
                  (InAppWebViewController controller, int newProgress) {
                setState(() {
                  progress = newProgress / 100.0;
                });
              },
              onLoadError: (InAppWebViewController controller, Uri? url,
                  int code, String message) {
                print("SVG load error: $message");
              },
              onLoadHttpError: (InAppWebViewController controller, Uri? url,
                  int statusCode, String description) {
                print("SVG HTTP error: $description");
              },
            ),
          ),
        ],
      ),
    );
  }
}

class WBViewWidget extends StatefulWidget {
  final String media; // Absolute file path
  final VoidCallback onMediaEnd;

  const WBViewWidget({
    Key? key,
    required this.media,
    required this.onMediaEnd,
  }) : super(key: key);

  @override
  _WBViewWidgetState createState() => _WBViewWidgetState();
}

class _WBViewWidgetState extends State<WBViewWidget> {
  InAppWebViewController? _webViewController;
  double progress = 0;
  @override
  void dispose() {
    _webViewController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String fileUrl = 'file://${widget.media}';

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: Column(
        children: [
          if (progress < 1.0) LinearProgressIndicator(value: progress),
          Expanded(
            child: InAppWebView(
              initialUrlRequest:
                  URLRequest(url: WebUri.uri(Uri.parse(fileUrl))),
              onWebViewCreated: (InAppWebViewController controller) {
                _webViewController = controller;
              },
              onProgressChanged: (controller, newProgress) {
                setState(() {
                  progress = newProgress / 100.0;
                });
              },
              onLoadError: (controller, url, code, message) {
                print("Load error: $message");
              },
              onLoadHttpError: (controller, url, statusCode, description) {
                print("HTTP error: $description");
              },
            ),
          ),
        ],
      ),
    );
  }
}
