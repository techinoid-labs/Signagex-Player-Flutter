import 'dart:convert';

CampaignResponse campaignResponseFromJson(String str) =>
    CampaignResponse.fromJson(json.decode(str));

String campaignResponseToJson(CampaignResponse data) =>
    json.encode(data.toJson());

class CampaignResponse {
  String? action;
  String? sender;
  CampaignData? data;

  CampaignResponse({
    this.action,
    this.sender,
    this.data,
  });

  factory CampaignResponse.fromJson(Map<String, dynamic> json) =>
      CampaignResponse(
        action: json["action"],
        sender: json["sender"],
        data: json["data"] == null ? null : CampaignData.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "sender": sender,
        "data": data?.toJson(),
      };
}

// ============================================
// CAMPAIGN DATA
// ============================================

class CampaignData {
  bool? success;
  String? message;
  List<Campaign>? playerCampaigns;

  CampaignData({
    this.success,
    this.message,
    this.playerCampaigns,
  });

  factory CampaignData.fromJson(Map<String, dynamic> json) => CampaignData(
        success: json["success"],
        message: json["message"],
        playerCampaigns: json["playerCampaigns"] == null
            ? null
            : List<Campaign>.from(
                json["playerCampaigns"].map((x) => Campaign.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "message": message,
        "playerCampaigns": playerCampaigns == null
            ? null
            : List<dynamic>.from(playerCampaigns!.map((x) => x.toJson())),
      };
}

// ============================================
// CORE CAMPAIGN MODEL
// ============================================

class Campaign {
  String? playbackType;
  String? campaignId;
  String? campaignName;
  Resolution? resolution;
  CampaignSchedule? campaignSchedule;
  CampaignSettings? campaignSettings;
  List<CampaignZone>? zones;
  bool? isPaused;

  Campaign({
    this.playbackType,
    this.campaignId,
    this.campaignName,
    this.resolution,
    this.campaignSchedule,
    this.campaignSettings,
    this.zones,
    this.isPaused,
  });

  factory Campaign.fromJson(Map<String, dynamic> json) => Campaign(
        playbackType: json["playback_type"],
        campaignId: json["campaign_id"],
        campaignName: json["campaign_name"],
        resolution: json["resolution"] == null
            ? null
            : Resolution.fromJson(json["resolution"]),
        campaignSchedule: json["campaign_schedule"] == null
            ? null
            : CampaignSchedule.fromJson(json["campaign_schedule"]),
        campaignSettings: json["campaign_settings"] == null
            ? null
            : CampaignSettings.fromJson(json["campaign_settings"]),
        zones: json["zones"] == null
            ? null
            : List<CampaignZone>.from(
                json["zones"].map((x) => CampaignZone.fromJson(x))),
        isPaused: json["is_paused"],
      );

  Map<String, dynamic> toJson() => {
        "playback_type": playbackType,
        "campaign_id": campaignId,
        "campaign_name": campaignName,
        "resolution": resolution?.toJson(),
        "campaign_schedule": campaignSchedule?.toJson(),
        "campaign_settings": campaignSettings?.toJson(),
        "zones": zones == null
            ? null
            : List<dynamic>.from(zones!.map((x) => x.toJson())),
        "is_paused": isPaused,
      };
}

// ============================================
// CAMPAIGN STRUCTURE MODELS
// ============================================

class Resolution {
  int? width;
  int? height;

  Resolution({
    this.width,
    this.height,
  });

  factory Resolution.fromJson(Map<String, dynamic> json) => Resolution(
        width: json["width"],
        height: json["height"],
      );

  Map<String, dynamic> toJson() => {
        "width": width,
        "height": height,
      };
}

class CampaignSchedule {
  bool? alwaysPlay;
  Period? period;

  CampaignSchedule({
    this.alwaysPlay,
    this.period,
  });

  factory CampaignSchedule.fromJson(Map<String, dynamic> json) =>
      CampaignSchedule(
        alwaysPlay: json["always_play"],
        period: json["period"] == null ? null : Period.fromJson(json["period"]),
      );

  Map<String, dynamic> toJson() => {
        "always_play": alwaysPlay,
        "period": period?.toJson(),
      };
}

class CampaignSettings {
  String? transition;
  int? duration; // Changed to int to match Settings
  bool? loop;

  CampaignSettings({
    this.transition,
    this.duration,
    this.loop,
  });

  factory CampaignSettings.fromJson(Map<String, dynamic> json) {
    // Handle duration as int or string, convert string to int
    int? durationValue;
    if (json["duration"] != null) {
      if (json["duration"] is int) {
        durationValue = json["duration"] as int;
      } else if (json["duration"] is String) {
        durationValue = int.tryParse(json["duration"] as String);
      }
    }

    return CampaignSettings(
      transition: json["transition"],
      duration: durationValue,
      loop: json["loop"],
    );
  }

  Map<String, dynamic> toJson() => {
        "transition": transition,
        "duration": duration,
        "loop": loop,
      };
}

class CampaignZone {
  int? id;
  int? x;
  int? y;
  int? width;
  int? height;
  List<MediaItem>? mediaItems;

  CampaignZone({
    this.id,
    this.x,
    this.y,
    this.width,
    this.height,
    this.mediaItems,
  });

  factory CampaignZone.fromJson(Map<String, dynamic> json) => CampaignZone(
        id: json["id"],
        x: json["x"],
        y: json["y"],
        width: json["width"],
        height: json["height"],
        mediaItems: json["mediaItems"] == null
            ? null
            : List<MediaItem>.from(
                json["mediaItems"].map((x) => MediaItem.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "x": x,
        "y": y,
        "width": width,
        "height": height,
        "mediaItems": mediaItems == null
            ? null
            : List<dynamic>.from(mediaItems!.map((x) => x.toJson())),
      };
}

// ============================================
// MEDIA MODELS
// ============================================

class MediaItem {
  Settings? settings;
  Schedule? schedule;
  String? mediaType;
  String? mediaUrl;
  List<CampaignZone>? zones; // For nested campaigns
  String? id;

  MediaItem({
    this.settings,
    this.schedule,
    this.mediaType,
    this.mediaUrl,
    this.zones,
    this.id,
  });

  factory MediaItem.fromJson(Map<String, dynamic> json) => MediaItem(
        settings: json["settings"] == null
            ? null
            : Settings.fromJson(json["settings"]),
        schedule: json["schedule"] == null
            ? null
            : Schedule.fromJson(json["schedule"]),
        mediaType: json["mediaType"],
        mediaUrl: json["mediaUrl"],
        zones: json["zones"] == null
            ? null
            : List<CampaignZone>.from(
                json["zones"].map((x) => CampaignZone.fromJson(x))),
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "settings": settings?.toJson(),
        "schedule": schedule?.toJson(),
        "mediaType": mediaType,
        "mediaUrl": mediaUrl,
        "zones": zones == null
            ? null
            : List<dynamic>.from(zones!.map((x) => x.toJson())),
        "id": id,
      };
}

class Settings {
  int? duration;
  String? transition;
  String? ratio;
  int? volume;
  bool? loop;
  int? otherMediaDefaultVolume;
  bool? isPaused;

  Settings({
    this.duration,
    this.transition,
    this.ratio,
    this.volume,
    this.loop,
    this.otherMediaDefaultVolume,
    this.isPaused,
  });

  factory Settings.fromJson(Map<String, dynamic> json) {
    // Handle duration as int or string, convert string to int
    int? durationValue;
    if (json["duration"] != null) {
      if (json["duration"] is int) {
        durationValue = json["duration"] as int;
      } else if (json["duration"] is String) {
        durationValue = int.tryParse(json["duration"] as String);
      }
    }

    return Settings(
      duration: durationValue,
      transition: json["transition"],
      ratio: json["ratio"],
      volume: json["volume"],
      loop: json["loop"] ?? false,
      otherMediaDefaultVolume: json["other_media_default_volume"],
      isPaused: json["is_paused"],
    );
  }

  Map<String, dynamic> toJson() => {
        "duration": duration,
        "transition": transition,
        "ratio": ratio,
        "volume": volume,
        "loop": loop ?? false,
        "other_media_default_volume": otherMediaDefaultVolume,
        "is_paused": isPaused,
      };
}

class Schedule {
  bool? alwaysPlay;
  Period? period;

  Schedule({
    this.alwaysPlay,
    this.period,
  });

  factory Schedule.fromJson(Map<String, dynamic> json) => Schedule(
        alwaysPlay: json["always_play"],
        period: json["period"] == null ? null : Period.fromJson(json["period"]),
      );

  Map<String, dynamic> toJson() => {
        "always_play": alwaysPlay,
        "period": period?.toJson(),
      };
}

// ============================================
// TIME/SCHEDULING MODELS
// ============================================

class Period {
  Days? days;
  Time? time;
  Date? date;

  Period({
    this.days,
    this.time,
    this.date,
  });

  factory Period.fromJson(Map<String, dynamic> json) => Period(
        days: json["days"] == null ? null : Days.fromJson(json["days"]),
        time: json["time"] == null ? null : Time.fromJson(json["time"]),
        date: json["date"] == null ? null : Date.fromJson(json["date"]),
      );

  Map<String, dynamic> toJson() => {
        "days": days?.toJson(),
        "time": time?.toJson(),
        "date": date?.toJson(),
      };
}

class Days {
  bool? monday;
  bool? tuesday;
  bool? wednesday;
  bool? thursday;
  bool? friday;
  bool? saturday;
  bool? sunday;

  Days({
    this.monday,
    this.tuesday,
    this.wednesday,
    this.thursday,
    this.friday,
    this.saturday,
    this.sunday,
  });

  factory Days.fromJson(Map<String, dynamic> json) => Days(
        monday: json["monday"],
        tuesday: json["tuesday"],
        wednesday: json["wednesday"],
        thursday: json["thursday"],
        friday: json["friday"],
        saturday: json["saturday"],
        sunday: json["sunday"],
      );

  Map<String, dynamic> toJson() => {
        "monday": monday,
        "tuesday": tuesday,
        "wednesday": wednesday,
        "thursday": thursday,
        "friday": friday,
        "saturday": saturday,
        "sunday": sunday,
      };
}

class Time {
  String? from;
  String? to;

  Time({
    this.from,
    this.to,
  });

  factory Time.fromJson(Map<String, dynamic> json) => Time(
        from: json["from"],
        to: json["to"],
      );

  Map<String, dynamic> toJson() => {
        "from": from,
        "to": to,
      };
}

class Date {
  String? start;
  String? end;

  Date({
    this.start,
    this.end,
  });

  factory Date.fromJson(Map<String, dynamic> json) => Date(
        start: json["start"],
        end: json["end"],
      );

  Map<String, dynamic> toJson() => {
        "start": start,
        "end": end,
      };
}

// ============================================
// LEGACY SUPPORT - Keep old class names for backward compatibility
// ============================================

// Alias for backward compatibility
typedef CampaignModel = CampaignResponse;
typedef Data = CampaignData;
typedef PlayerCampaign = Campaign;
typedef Zone = CampaignZone;

// Legacy factory functions
CampaignModel campaignModelFromJson(String str) =>
    CampaignResponse.fromJson(json.decode(str));

String campaignModelToJson(CampaignModel data) => json.encode(data.toJson());
