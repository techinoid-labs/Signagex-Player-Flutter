import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import 'package:digital_signage/models/compaign_model.dart';
import 'package:digital_signage/view_models/mqtt_view_model.dart';

class CampaignView extends StatefulWidget {
  const CampaignView({super.key});

  @override
  State<CampaignView> createState() => _CampaignViewState();
}

class _CampaignViewState extends State<CampaignView> {
  late FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _focusNode = FocusNode();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final mqttViewModel = Provider.of<MqttViewModel>(context, listen: false);
      mqttViewModel.startPlaylistTimerForCampaign();
    });
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mqttViewModel = Provider.of<MqttViewModel>(context);
    final campaignModel = mqttViewModel.campaignModel;

    if (campaignModel?.data?.playerCampaigns?.isEmpty ?? true) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text(
            "No campaign data available",
            style: TextStyle(color: Colors.white),
          ),
        ),
      );
    }

    final campaign = campaignModel
        ?.data?.playerCampaigns?[mqttViewModel.currentIndexOfCapmaign];
    if (campaign == null) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text(
            "No campaign data available",
            style: TextStyle(color: Colors.white),
          ),
        ),
      );
    }

    final campaignSchedule = campaign.campaignSchedule;

    if (campaignSchedule?.alwaysPlay ?? false) {
      return _buildZones(campaign);
    }

    if (campaignSchedule?.period == null) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text(
            "Campaign schedule not configured.",
            style: TextStyle(color: Colors.white),
          ),
        ),
      );
    }

    DateTime now = DateTime.now();

    bool isCampaignDateInRange = false;
    if (campaignSchedule?.period?.date?.start != null &&
        campaignSchedule?.period?.date?.end != null) {
      isCampaignDateInRange = _isCampaignDateInRange(
        DateTime.parse(campaignSchedule!.period!.date!.start!),
        DateTime.parse(campaignSchedule!.period!.date!.end!),
      );
    }

    bool isCampaignDayAllowed = false;
    if (campaignSchedule?.period?.days != null) {
      isCampaignDayAllowed = _isCurrentDayAllowed(
        campaignSchedule!.period!.days!,
        now,
      );
    }

    bool isCampaignTimeInRange = false;
    if (campaignSchedule?.period?.time?.from != null &&
        campaignSchedule?.period?.time?.to != null) {
      isCampaignTimeInRange = _isTimeInRange(
        campaignSchedule!.period!.time!.from!,
        campaignSchedule!.period!.time!.to!,
      );
    }

    if (isCampaignDateInRange &&
        isCampaignDayAllowed &&
        isCampaignTimeInRange) {
      return _buildZones(campaign);
    }

    return const Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Text(
          "Campaign is not scheduled to play at this time.",
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }

  Widget _buildZones(PlayerCampaign campaign) {
    // Get device screen size
    final screenSize = MediaQuery.of(context).size;
    final deviceWidth = screenSize.width;
    final deviceHeight = screenSize.height;

    // Get campaign resolution
    final campaignWidth = campaign.resolution?.width?.toDouble() ?? deviceWidth;
    final campaignHeight =
        campaign.resolution?.height?.toDouble() ?? deviceHeight;

    // Calculate scaling factors
    final scaleX = deviceWidth / campaignWidth;
    final scaleY = deviceHeight / campaignHeight;

    print("Campaign resolution: ${campaignWidth}x${campaignHeight}");
    print("Device resolution: ${deviceWidth}x${deviceHeight}");
    print("Scale factors: X=$scaleX, Y=$scaleY");

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: (details) {
          // Capture the tap position and store it in the Provider
          final mqttViewModel =
              Provider.of<MqttViewModel>(context, listen: false);
          mqttViewModel.setTapPosition(
              details.localPosition.dx, details.localPosition.dy);
          print(
              "Tapped at: x=${details.localPosition.dx}, y=${details.localPosition.dy}");
        },
        child: Stack(
          children: (campaign.zones ?? []).map((zone) {
            // Scale zone coordinates and dimensions based on resolution
            final scaledX = (zone.x ?? 0) * scaleX;
            final scaledY = (zone.y ?? 0) * scaleY;
            final scaledWidth = (zone.width ?? 0) * scaleX;
            final scaledHeight = (zone.height ?? 0) * scaleY;

            return Positioned(
              left: scaledX,
              top: scaledY,
              width: scaledWidth,
              height: scaledHeight,
              child: VideoPlaylistWidget(
                zoneId: (zone.id ?? 0).toString(),
                mediaItems: zone.mediaItems ?? [],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  bool _isCampaignDateInRange(DateTime startDate, DateTime endDate) {
    DateTime now = DateTime.now();
    return now.isAfter(startDate) &&
        now.isBefore(endDate.add(const Duration(days: 1)));
  }

  bool _isCurrentDayAllowed(dynamic days, DateTime now) {
    switch (now.weekday) {
      case 1:
        return days.monday ?? false;
      case 2:
        return days.tuesday ?? false;
      case 3:
        return days.wednesday ?? false;
      case 4:
        return days.thursday ?? false;
      case 5:
        return days.friday ?? false;
      case 6:
        return days.saturday ?? false;
      case 7:
        return days.sunday ?? false;
      default:
        return false;
    }
  }

  bool _isTimeInRange(String timeFrom, String timeTo) {
    DateTime currentTime = DateTime.now();
    DateTime fromTime = DateTime.now().copyWith(
      hour: int.parse(timeFrom.split(':')[0]),
      minute: int.parse(timeFrom.split(':')[1]),
    );

    DateTime toTime = DateTime.now().copyWith(
      hour: int.parse(timeTo.split(':')[0]),
      minute: int.parse(timeTo.split(':')[1]),
    );

    return currentTime.isAfter(fromTime) && currentTime.isBefore(toTime);
  }
}

class VideoPlaylistWidget extends StatefulWidget {
  final String zoneId;
  final List<MediaItem> mediaItems;

  const VideoPlaylistWidget({
    super.key,
    required this.zoneId,
    required this.mediaItems,
  });

  @override
  _VideoPlaylistWidgetState createState() => _VideoPlaylistWidgetState();
}

class _VideoPlaylistWidgetState extends State<VideoPlaylistWidget> {
  int _currentMediaIndex = 0;
  Timer? _timer;
  double _opacity = 1.0;
  VideoPlayerController? _videoController;
  DateTime? _videoStartTime; // Track when video started playing
  int? _targetDuration; // Target duration in seconds

  @override
  void initState() {
    super.initState();
    _timer = Timer(Duration.zero, () {});
    _initializeNextMedia();
  }

  @override
  void didUpdateWidget(covariant VideoPlaylistWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.mediaItems != widget.mediaItems ||
        oldWidget.zoneId != widget.zoneId) {
      _resetState();
    }
  }

  void _resetState() {
    _currentMediaIndex = 0;
    _timer?.cancel();
    _videoController?.removeListener(_checkVideoPlaybackDuration);
    _videoController?.dispose();
    _videoController = null;
    _videoStartTime = null;
    _targetDuration = null;
    setState(() {
      _opacity = 1.0;
    });
    _initializeNextMedia();
  }

  void _initializeNextMedia() {
    if (widget.mediaItems.isEmpty) {
      print("Zone ${widget.zoneId}: No media items available.");
      return;
    }

    MediaItem currentMedia = widget.mediaItems[_currentMediaIndex];
    print(
        "Zone ${widget.zoneId}: Initializing media item ${currentMedia.id ?? 'N/A'}...... ${currentMedia.mediaUrl ?? 'N/A'}");
    if (currentMedia.schedule?.alwaysPlay ?? false) {
      print("Always play is true for media: ${currentMedia.mediaUrl ?? 'N/A'}");
      // Duration is already an int in the model, convert to string for _startMediaLoop
      int? durationInt = currentMedia.settings?.duration;
      String duration = (durationInt ?? 0).toString();
      print("Loading duration at index $_currentMediaIndex: $duration seconds");
      _startMediaLoop(duration);
      _loadMedia(currentMedia);
      return;
    }
    DateTime now = DateTime.now();
    print("Current date: $now");

    if (currentMedia.schedule?.period?.date?.start == null ||
        currentMedia.schedule?.period?.date?.end == null) {
      print("Media schedule date is null, skipping");
      _onMediaEnd();
      return;
    }

    DateTime startDate =
        DateTime.parse(currentMedia.schedule!.period!.date!.start!);
    DateTime endDate =
        DateTime.parse(currentMedia.schedule!.period!.date!.end!);
    print("Media start date: $startDate");
    print("Media end date: $endDate");

    bool isDateInRange = now.isAfter(startDate) &&
        now.isBefore(endDate.add(const Duration(days: 1)));
    print("Is current date in range: $isDateInRange");

    bool isDayAllowed = false;
    if (currentMedia.schedule?.period?.days != null) {
      isDayAllowed =
          _isCurrentDayAllowed(currentMedia.schedule!.period!.days!, now);
    }
    print("Is current day allowed: $isDayAllowed");

    String? timeFrom = currentMedia.schedule?.period?.time?.from;
    String? timeTo = currentMedia.schedule?.period?.time?.to;

    if (timeFrom == null || timeTo == null) {
      print("Media schedule time is null, skipping");
      _onMediaEnd();
      return;
    }

    DateTime currentTime = DateTime.now();
    final fromParts = timeFrom.split(':');
    final toParts = timeTo.split(':');

    if (fromParts.length < 2 || toParts.length < 2) {
      print("Invalid time format, skipping");
      _onMediaEnd();
      return;
    }
    DateTime fromTime = DateTime.now().copyWith(
      hour: int.tryParse(fromParts[0]) ?? 0,
      minute: int.tryParse(fromParts[1]) ?? 0,
      second: fromParts.length > 2 ? (int.tryParse(fromParts[2]) ?? 0) : 0,
    );

    DateTime toTime = DateTime.now().copyWith(
      hour: int.tryParse(toParts[0]) ?? 0,
      minute: int.tryParse(toParts[1]) ?? 0,
      second: toParts.length > 2 ? (int.tryParse(toParts[2]) ?? 0) : 0,
    );

    bool isTimeInRange =
        currentTime.isAfter(fromTime) && currentTime.isBefore(toTime);
    print("Is current time in range: $isTimeInRange");

    if (isDateInRange && isDayAllowed && isTimeInRange) {
      // Duration is already an int in the model, convert to string for _startMediaLoop
      int? durationInt = currentMedia.settings?.duration;
      String duration = (durationInt ?? 0).toString();
      print("Loading duration at index $_currentMediaIndex: $duration seconds");
      _startMediaLoop(duration);
      _loadMedia(currentMedia);
    } else {
      print("Skipping media not allowed by schedule.");
      print("Current date, day, or time is not allowed for this media.");
      _onMediaEnd();
    }
  }

  void _startMediaLoop(String duration) {
    print("Starting media loop for duration: $duration");
    int durationSeconds = int.tryParse(duration) ?? 10;

    // Cancel any existing timer
    _timer?.cancel();

    // Only set timer if duration is greater than 0
    if (durationSeconds > 0) {
      _timer = Timer(Duration(seconds: durationSeconds), () {
        print(
            "[LOG] Media duration timer expired after $durationSeconds seconds");
        _onMediaEnd();
      });
    }
  }

  bool _isMediaAllowed(MediaItem media) {
    if (media.schedule?.period?.date?.start == null ||
        media.schedule?.period?.date?.end == null) {
      return false;
    }

    DateTime now = DateTime.now();
    DateTime startDate = DateTime.parse(media.schedule!.period!.date!.start!);
    DateTime endDate = DateTime.parse(media.schedule!.period!.date!.end!);

    bool isDateInRange = now.isAfter(startDate) &&
        now.isBefore(endDate.add(const Duration(days: 1)));
    bool isDayAllowed = false;
    if (media.schedule?.period?.days != null) {
      isDayAllowed = _isCurrentDayAllowed(media.schedule!.period!.days!, now);
    }
    bool isTimeInRange = false;
    if (media.schedule?.period?.time?.from != null &&
        media.schedule?.period?.time?.to != null) {
      isTimeInRange = _isTimeInRange(
        media.schedule!.period!.time!.from!,
        media.schedule!.period!.time!.to!,
      );
    }

    return isDateInRange && isDayAllowed && isTimeInRange;
  }

  void _loadMedia(MediaItem nextMedia) {
    final mediaUrl = nextMedia.mediaUrl ?? '';
    print("[LOG] Loading media: $mediaUrl");
    if (mediaUrl.isEmpty) {
      print("[LOG] Media URL is empty, skipping");
      _onMediaEnd();
      return;
    }

    if (isVideoFile(mediaUrl)) {
      _initializeNextVideo(nextMedia);
    } else if (isWebFile(mediaUrl)) {
      // Ensure you are not reinitializing the WebView if the file is the same
      if (_currentMediaIndex > 0 &&
          (widget.mediaItems[_currentMediaIndex - 1].mediaUrl ?? '') ==
              mediaUrl) {
        print("[LOG] Skipping recreation of the same WebView");
        return;
      }
      // HTML files use the timer from _startMediaLoop, no additional timer needed
      setState(() {});
    } else if (isSvgContent(mediaUrl)) {
      print("[LOG] Current media is SVG: ${nextMedia.mediaUrl}");
      // SVG content uses the timer from _startMediaLoop, no additional timer needed
      setState(() {});
    } else {
      print("[LOG] Current media is an image: ${nextMedia.mediaUrl}");
      // Images use the timer from _startMediaLoop, no additional timer needed
      setState(() {});
    }
  }

  void _initializeNextVideo(MediaItem nextMedia) {
    final mediaUrl = nextMedia.mediaUrl ?? '';
    if (mediaUrl.isEmpty) {
      print("[LOG] Video URL is empty, skipping");
      _onMediaEnd();
      return;
    }
    print("[LOG] Initializing video: $mediaUrl");

    // Get volume from settings (0-100, convert to 0.0-1.0)
    final volume = (nextMedia.settings?.volume ?? 100) / 100.0;
    print(
        "[LOG] Setting video volume to: $volume (${nextMedia.settings?.volume}%)");

    _videoController = VideoPlayerController.file(File(mediaUrl))
      ..initialize().then((_) {
        if (_videoController!.value.isInitialized) {
          int targetDuration = nextMedia.settings?.duration ??
              _videoController!.value.duration.inSeconds;
          int videoLength = _videoController!.value.duration.inSeconds;

          _targetDuration = targetDuration;
          _videoStartTime = DateTime.now();

          print("Target play duration: $targetDuration seconds");
          print("Video length: $videoLength seconds");

          setState(() {
            _videoController!.setVolume(volume.clamp(0.0, 1.0));
            _videoController!.play();

            // If video is shorter than target duration, loop it
            if (targetDuration > 0 &&
                videoLength > 0 &&
                videoLength < targetDuration) {
              _videoController!.setLooping(true);
              print(
                  "[LOG] Video ($videoLength sec) is shorter than target duration ($targetDuration sec), will loop");
            } else {
              _videoController!.setLooping(false);
            }
          });

          // Don't set timer here - it's already set in _startMediaLoop
          // Only add listener for safety check (if video ends naturally before timer)
          if (targetDuration > 0) {
            // Add listener to check if video ends naturally before timer expires
            _videoController!.addListener(_checkVideoPlaybackDuration);
          } else {
            // If no duration specified, let video play until end
            _videoController!.addListener(() {
              if (_videoController!.value.position >=
                      _videoController!.value.duration &&
                  _videoController!.value.position.inMilliseconds > 0) {
                print("[LOG] Video ended naturally, transitioning");
                _videoController!.removeListener(() {});
                _onMediaEnd();
              }
            });
          }
        }
      }).catchError((error) {
        print("[LOG] Error initializing video: $error");
        print("[LOG] Video URL: ${nextMedia.mediaUrl}");
        setState(() {});
      });
  }

  void _checkVideoPlaybackDuration() {
    if (_videoController == null ||
        _videoStartTime == null ||
        _targetDuration == null) {
      return;
    }

    // Safety check: Only transition if timer hasn't already fired
    // This prevents double transitions when both timer and listener fire
    if (_timer?.isActive ?? false) {
      final elapsed = DateTime.now().difference(_videoStartTime!).inSeconds;
      // Only transition if we're past the target duration AND timer is still active
      // This handles edge cases where video might end naturally before timer
      if (elapsed >= _targetDuration! &&
          _videoController!.value.position >=
              _videoController!.value.duration) {
        print("[LOG] Video ended naturally before timer, transitioning early");
        _videoController!.removeListener(_checkVideoPlaybackDuration);
        _timer?.cancel(); // Cancel timer since we're transitioning now
        _videoController!.pause();
        _onMediaEnd();
      }
    }
  }

  void _checkVideoDuration(MediaItem media) {
    // This method is no longer needed as we handle video end in _initializeNextVideo
    // Keep it for backward compatibility but it won't be called
  }

  void _showImage(MediaItem media) {
    int durationSeconds =
        int.tryParse(media.settings!.duration.toString()) ?? 5;
    _timer?.cancel();
    _timer = Timer(Duration(seconds: durationSeconds), _onMediaEnd);
  }

  bool _isDisposed = false;

  void _onMediaEnd() {
    // Cancel any active timers
    _timer?.cancel();

    // Remove video listener
    if (_videoController != null) {
      _videoController!.removeListener(_checkVideoPlaybackDuration);
    }

    if (!_isDisposed && mounted) {
      // Dispose current video controller before transitioning
      _videoController?.pause();
      _videoController?.dispose();
      _videoController = null;
      _videoStartTime = null;
      _targetDuration = null;

      final currentIndex = _currentMediaIndex;
      final totalMedia = widget.mediaItems.length;
      print("[LOG] Media ended at index $currentIndex of $totalMedia");

      setState(() {
        _opacity = 0.0;
      });

      // Wait for fade out transition, then move to next media
      Future.delayed(const Duration(milliseconds: 500), () {
        if (!mounted || _isDisposed) return;
        setState(() {
          if (_currentMediaIndex < widget.mediaItems.length - 1) {
            _currentMediaIndex++;
          } else {
            _currentMediaIndex = 0; // Loop back to first media
          }
          print(
              "[LOG] Transitioning to media index $_currentMediaIndex of ${widget.mediaItems.length}");
          print(
              "[LOG] Next media ID: ${widget.mediaItems[_currentMediaIndex].id ?? 'N/A'}");
          print(
              "[LOG] Next media URL: ${widget.mediaItems[_currentMediaIndex].mediaUrl ?? 'N/A'}");
          _opacity = 1.0;
          _initializeNextMedia();
        });
      });
    }
  }

  bool _isCurrentDayAllowed(dynamic days, DateTime now) {
    switch (now.weekday) {
      case DateTime.monday:
        return days.monday ?? false;
      case DateTime.tuesday:
        return days.tuesday ?? false;
      case DateTime.wednesday:
        return days.wednesday ?? false;
      case DateTime.thursday:
        return days.thursday ?? false;
      case DateTime.friday:
        return days.friday ?? false;
      case DateTime.saturday:
        return days.saturday ?? false;
      case DateTime.sunday:
        return days.sunday ?? false;
      default:
        return false;
    }
  }

  bool _isTimeInRange(String timeFrom, String timeTo) {
    DateTime currentTime = DateTime.now();
    DateTime fromTime = DateTime.now().copyWith(
      hour: int.parse(timeFrom.split(':')[0]),
      minute: int.parse(timeFrom.split(':')[1]),
    );
    DateTime toTime = DateTime.now().copyWith(
      hour: int.parse(timeTo.split(':')[0]),
      minute: int.parse(timeTo.split(':')[1]),
    );

    return currentTime.isAfter(fromTime) && currentTime.isBefore(toTime);
  }

  bool isWebFile(String path) {
    final webExtensions = ['.html'];
    return webExtensions.any((ext) => path.endsWith(ext));
  }

  bool isSvgContent(String content) {
    // Check if content is SVG code (starts with <svg or contains <svg tag)
    final trimmed = content.trim();
    return trimmed.startsWith('<svg') ||
        (trimmed.contains('<svg') && trimmed.contains('</svg>'));
  }

  @override
  void dispose() {
    _timer?.cancel();
    _isDisposed = true;
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.mediaItems.isEmpty) {
      return Center(child: Text("Zone ${widget.zoneId}: No media items."));
    }

    MediaItem currentMedia = widget.mediaItems[_currentMediaIndex];
    return AnimatedOpacity(
      opacity: _opacity,
      duration: const Duration(milliseconds: 500),
      child: AnimatedSwitcher(
        key: ValueKey(currentMedia.id),
        duration: const Duration(milliseconds: 500),
        transitionBuilder: (child, animation) {
          print(
              "this is transition${currentMedia.settings?.transition ?? 'none'}");

          switch (currentMedia.settings?.transition ?? 'none') {
            case "fadeIn":
              return FadeTransition(opacity: animation, child: child);
            case "slideOverLeftToRight":
              return SlideTransition(
                position: animation.drive(
                  Tween(
                    begin: const Offset(-1, 0), // From left
                    end: Offset.zero,
                  ).chain(CurveTween(curve: Curves.easeInOut)),
                ),
                child: child,
              );
            case "slideOverRightToLeft":
              return SlideTransition(
                position: animation.drive(
                  Tween(
                    begin: const Offset(1, 0),
                    end: Offset.zero,
                  ).chain(CurveTween(curve: Curves.easeInOut)),
                ),
                child: child,
              );
            case "slideOverTopToBottom":
              return SlideTransition(
                position: animation.drive(
                  Tween(
                    begin: const Offset(0, -1), // From top
                    end: Offset.zero,
                  ).chain(CurveTween(curve: Curves.easeInOut)),
                ),
                child: child,
              );
            case "slideOverBottomToTop":
              return SlideTransition(
                position: animation.drive(
                  Tween(
                    begin: const Offset(0, 1), // From bottom
                    end: Offset.zero,
                  ).chain(CurveTween(curve: Curves.easeInOut)),
                ),
                child: child,
              );
            case "slideInOutLeftToRight":
              return Stack(
                children: [
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: const Offset(-1, 0), // From left
                        end: Offset.zero,
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: Offset.zero,
                        end: const Offset(1, 0), // Slide out to right
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                ],
              );
            case "slideInOutRightToLeft":
              return Stack(
                children: [
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: const Offset(1, 0), // From right
                        end: Offset.zero,
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: Offset.zero,
                        end: const Offset(-1, 0), // Slide out to left
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                ],
              );
            case "slideInOutTopToBottom":
              return Stack(
                children: [
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: const Offset(0, -1), // From top
                        end: Offset.zero,
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: Offset.zero,
                        end: const Offset(0, 1), // Slide out to bottom
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                ],
              );
            case "slideInOutBottomToTop":
              return Stack(
                children: [
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: const Offset(0, 1), // From bottom
                        end: Offset.zero,
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                  SlideTransition(
                    position: animation.drive(
                      Tween(
                        begin: Offset.zero,
                        end: const Offset(0, -1), // Slide out to top
                      ).chain(CurveTween(curve: Curves.easeInOut)),
                    ),
                    child: child,
                  ),
                ],
              );
            default:
              return child; // No transition applied
          }
        },
        child: isVideoFile(currentMedia.mediaUrl ?? '')
            ? VideoPlayerWidget(
                key: ValueKey('${currentMedia.id ?? ''}_${_currentMediaIndex}'),
                filePath: currentMedia.mediaUrl ?? '',
                onVideoEnd: () {
                  // Only call _onMediaEnd if timer is not active (already fired or no duration set)
                  // This prevents double transitions when video ends naturally
                  if (!(_timer?.isActive ?? false)) {
                    print(
                        "[LOG] Video ended naturally, timer already expired or not set");
                    _onMediaEnd();
                  } else {
                    print(
                        "[LOG] Video ended naturally but timer is still active, waiting for timer");
                  }
                },
                transitionType: currentMedia.settings?.transition ?? 'none',
                volume: (currentMedia.settings?.volume ?? 100) / 100.0,
              )
            : isWebFile(currentMedia.mediaUrl ?? '')
                ? WBViewWidget(
                    key: ValueKey(currentMedia.id ?? ''),
                    media: currentMedia.mediaUrl ?? '',
                    onMediaEnd: _onMediaEnd)
                : isSvgContent(currentMedia.mediaUrl ?? '')
                    ? SvgWidget(
                        key: ValueKey(currentMedia.id ?? ''),
                        svgContent: currentMedia.mediaUrl ?? '',
                        onSvgEnd: _onMediaEnd,
                        transitionType:
                            currentMedia.settings?.transition ?? 'none',
                      )
                    : ImageWidget(
                        key: ValueKey(currentMedia.id ?? ''),
                        filePath: currentMedia.mediaUrl ?? '',
                        onImageEnd: _onMediaEnd,
                        transitionType:
                            currentMedia.settings?.transition ?? 'none',
                      ),
      ),
    );
  }

  bool isVideoFile(String path) {
    final videoExtensions = ['.mp4', '.avi', '.mov', '.mkv'];
    return videoExtensions.any((ext) => path.endsWith(ext));
  }
}

class VideoPlayerWidget extends StatefulWidget {
  final String filePath;
  final VoidCallback onVideoEnd;
  final String transitionType;
  final double volume;

  const VideoPlayerWidget({
    super.key,
    required this.filePath,
    required this.onVideoEnd,
    required this.transitionType,
    this.volume = 1.0,
  });

  @override
  _VideoPlayerWidgetState createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _controller;
  bool _isLoading = true;
  bool _isVideoEnded = false;

  @override
  void initState() {
    super.initState();
    _initializeVideo();
  }

  void _initializeVideo() async {
    _controller = VideoPlayerController.file(File(widget.filePath))
      ..initialize().then(
        (_) {
          setState(
            () {
              _isLoading = false;
              _controller.setVolume(widget.volume.clamp(0.0, 1.0));
              _controller.setLooping(false);
              _controller.play();
            },
          );

          _controller.addListener(
            () {
              if (_controller.value.position >= _controller.value.duration &&
                  !_isVideoEnded) {
                _isVideoEnded = true;
                widget.onVideoEnd();
              }
            },
          );
        },
      ).catchError(
        (error) {
          print("Error initializing video: $error");
          setState(
            () {
              _isLoading = false;
            },
          );
        },
      );
  }

  void _checkVideoEnd() {
    if (_controller.value.isInitialized &&
        !_controller.value.isPlaying &&
        _controller.value.position >= _controller.value.duration &&
        !_isVideoEnded) {
      setState(() {
        _isVideoEnded = true;
      });
      widget.onVideoEnd();
    }
  }

  @override
  void didUpdateWidget(covariant VideoPlayerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.filePath != widget.filePath) {
      _controller.removeListener(_checkVideoEnd);
      _controller.dispose();
      _initializeVideo();
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget videoWidget = _isLoading
        ? const Center(child: CircularProgressIndicator())
        : SizedBox.expand(child: VideoPlayer(_controller));

    if (!_isLoading && !_controller.value.isInitialized) {
      videoWidget = const Center(child: CircularProgressIndicator());
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: videoWidget,
    );
  }

  @override
  void dispose() {
    _controller.removeListener(_checkVideoEnd);
    _controller.dispose();
    super.dispose();
  }
}

class ImageWidget extends StatelessWidget {
  final String filePath;
  final VoidCallback onImageEnd;

  final String transitionType;

  const ImageWidget({
    super.key,
    required this.filePath,
    required this.onImageEnd,
    required this.transitionType,
  });

  @override
  Widget build(BuildContext context) {
    Widget imageWidget = SizedBox.expand(
      child: Image.file(
        File(filePath),
        fit: BoxFit.cover,
        height: MediaQuery.sizeOf(context).height,
        width: MediaQuery.sizeOf(context).width,
      ),
    );

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: imageWidget,
    );
  }
}

class SvgWidget extends StatefulWidget {
  final String svgContent;
  final VoidCallback onSvgEnd;
  final String transitionType;

  const SvgWidget({
    super.key,
    required this.svgContent,
    required this.onSvgEnd,
    required this.transitionType,
  });

  @override
  _SvgWidgetState createState() => _SvgWidgetState();
}

class _SvgWidgetState extends State<SvgWidget> {
  InAppWebViewController? _webViewController;
  double progress = 0;

  @override
  void dispose() {
    _webViewController?.dispose();
    super.dispose();
  }

  String _createSvgHtml(String svgContent) {
    // Create an HTML page that centers and scales the SVG to fill the viewport
    return '''
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    html, body {
      width: 100%;
      height: 100%;
      overflow: hidden;
      background: transparent;
    }
    body {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    svg {
      width: 100%;
      height: 100%;
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }
  </style>
</head>
<body>
  $svgContent
</body>
</html>
''';
  }

  @override
  Widget build(BuildContext context) {
    // Create HTML content with SVG embedded
    final htmlContent = _createSvgHtml(widget.svgContent);

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: Column(
        children: [
          if (progress < 1.0) LinearProgressIndicator(value: progress),
          Expanded(
            child: InAppWebView(
              initialData: InAppWebViewInitialData(
                data: htmlContent,
                mimeType: 'text/html',
                encoding: 'utf-8',
              ),
              initialSettings: InAppWebViewSettings(
                transparentBackground: true,
                useShouldOverrideUrlLoading: true,
                javaScriptEnabled: true,
                domStorageEnabled: true,
              ),
              onWebViewCreated: (InAppWebViewController controller) {
                _webViewController = controller;
              },
              onProgressChanged:
                  (InAppWebViewController controller, int newProgress) {
                setState(() {
                  progress = newProgress / 100.0;
                });
              },
              onLoadError: (InAppWebViewController controller, Uri? url,
                  int code, String message) {
                print("SVG load error: $message");
              },
              onLoadHttpError: (InAppWebViewController controller, Uri? url,
                  int statusCode, String description) {
                print("SVG HTTP error: $description");
              },
            ),
          ),
        ],
      ),
    );
  }
}

class WBViewWidget extends StatefulWidget {
  final String media; // Absolute file path
  final VoidCallback onMediaEnd;

  const WBViewWidget({
    Key? key,
    required this.media,
    required this.onMediaEnd,
  }) : super(key: key);

  @override
  _WBViewWidgetState createState() => _WBViewWidgetState();
}

class _WBViewWidgetState extends State<WBViewWidget> {
  InAppWebViewController? _webViewController;
  double progress = 0;
  @override
  void dispose() {
    _webViewController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String fileUrl = 'file://${widget.media}';

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: Column(
        children: [
          if (progress < 1.0) LinearProgressIndicator(value: progress),
          Expanded(
            child: InAppWebView(
              initialUrlRequest:
                  URLRequest(url: WebUri.uri(Uri.parse(fileUrl))),
              onWebViewCreated: (InAppWebViewController controller) {
                _webViewController = controller;
              },
              onProgressChanged: (controller, newProgress) {
                setState(() {
                  progress = newProgress / 100.0;
                });
              },
              onLoadError: (controller, url, code, message) {
                print("Load error: $message");
              },
              onLoadHttpError: (controller, url, statusCode, description) {
                print("HTTP error: $description");
              },
            ),
          ),
        ],
      ),
    );
  }
}
