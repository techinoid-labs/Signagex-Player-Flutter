import 'package:flutter/material.dart';

class TransitionUtils {
  static Widget buildTransition(
      Widget child, Animation<double> animation, String transitionType) {
    switch (transitionType) {
      case "fadeIn":
        return FadeTransition(opacity: animation, child: child);
      case "slideOverLeftToRight":
        return SlideTransition(
          position: animation.drive(
            Tween(
              begin: const Offset(-1, 0),
              end: Offset.zero,
            ).chain(CurveTween(curve: Curves.easeInOut)),
          ),
          child: child,
        );
      case "slideOverRightToLeft":
        return SlideTransition(
          position: animation.drive(
            Tween(
              begin: const Offset(1, 0),
              end: Offset.zero,
            ).chain(CurveTween(curve: Curves.easeInOut)),
          ),
          child: child,
        );
      case "slideOverTopToBottom":
        return SlideTransition(
          position: animation.drive(
            Tween(
              begin: const Offset(0, -1),
              end: Offset.zero,
            ).chain(CurveTween(curve: Curves.easeInOut)),
          ),
          child: child,
        );
      case "slideOverBottomToTop":
        return SlideTransition(
          position: animation.drive(
            Tween(
              begin: const Offset(0, 1),
              end: Offset.zero,
            ).chain(CurveTween(curve: Curves.easeInOut)),
          ),
          child: child,
        );
      case "slideInOutLeftToRight":
        return Stack(
          children: [
            SlideTransition(
              position: animation.drive(
                Tween(
                  begin: const Offset(-1, 0),
                  end: Offset.zero,
                ).chain(CurveTween(curve: Curves.easeInOut)),
              ),
              child: child,
            ),
            SlideTransition(
              position: animation.drive(
                Tween(
                  begin: Offset.zero,
                  end: const Offset(1, 0),
                ).chain(CurveTween(curve: Curves.easeInOut)),
              ),
              child: child,
            ),
          ],
        );
      case "slideInOutRightToLeft":
        return Stack(
          children: [
            SlideTransition(
              position: animation.drive(
                Tween(
                  begin: const Offset(1, 0),
                  end: Offset.zero,
                ).chain(CurveTween(curve: Curves.easeInOut)),
              ),
              child: child,
            ),
            SlideTransition(
              position: animation.drive(
                Tween(
                  begin: Offset.zero,
                  end: const Offset(-1, 0),
                ).chain(CurveTween(curve: Curves.easeInOut)),
              ),
              child: child,
            ),
          ],
        );
      case "slideInOutTopToBottom":
        return Stack(
          children: [
            SlideTransition(
              position: animation.drive(
                Tween(
                  begin: const Offset(0, -1),
                  end: Offset.zero,
                ).chain(CurveTween(curve: Curves.easeInOut)),
              ),
              child: child,
            ),
            SlideTransition(
              position: animation.drive(
                Tween(
                  begin: Offset.zero,
                  end: const Offset(0, 1),
                ).chain(CurveTween(curve: Curves.easeInOut)),
              ),
              child: child,
            ),
          ],
        );
      case "slideInOutBottomToTop":
        return Stack(
          children: [
            SlideTransition(
              position: animation.drive(
                Tween(
                  begin: const Offset(0, 1),
                  end: Offset.zero,
                ).chain(CurveTween(curve: Curves.easeInOut)),
              ),
              child: child,
            ),
            SlideTransition(
              position: animation.drive(
                Tween(
                  begin: Offset.zero,
                  end: const Offset(0, -1),
                ).chain(CurveTween(curve: Curves.easeInOut)),
              ),
              child: child,
            ),
          ],
        );
      default:
        return child;
    }
  }
}
