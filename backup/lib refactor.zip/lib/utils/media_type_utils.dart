class MediaTypeUtils {
  static bool isVideoFile(String path) {
    final videoExtensions = ['.mp4', '.avi', '.mov', '.mkv'];
    return videoExtensions.any((ext) => path.endsWith(ext));
  }

  static bool isWebFile(String path) {
    final webExtensions = ['.html'];
    return webExtensions.any((ext) => path.endsWith(ext));
  }

  static bool isSvgContent(String content) {
    final trimmed = content.trim();
    return trimmed.startsWith('<svg') ||
        (trimmed.contains('<svg') && trimmed.contains('</svg>'));
  }

  static String decodeSvgContent(String content) {
    try {
      final decoded = Uri.decodeComponent(content);
      if (decoded != content && isSvgContent(decoded)) {
        return decoded;
      }
      if (isSvgContent(content)) {
        return content;
      }
      return content;
    } catch (e) {
      print("[LOG] SVG decode error: $e");
      return content;
    }
  }
}
