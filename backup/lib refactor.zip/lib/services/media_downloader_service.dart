import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';

import 'package:digital_signage/models/compaign_model.dart';

import '../utils/media_type_utils.dart';

class MediaDownloaderService {
  Future<String> ensureLocalMediaUrl(String url, {Function(int received, int total)? onProgress}) async {
    final trimmed = url.trim();

    if (MediaTypeUtils.isSvgContent(trimmed)) {
      return trimmed;
    }

    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      return trimmed;
    }

    final filename = _extractFilename(trimmed);
    final directory = await _getDirectory();
    if (directory == null) {
      throw Exception('Unable to determine directory');
    }

    final filePath = '${directory.path}/$filename';
    final file = File(filePath);
    final exists = await file.exists();
    if (exists) {
      print('File already exists: $filePath');
      return filePath;
    }

    final dio = Dio();
    dio.options.connectTimeout = const Duration(seconds: 30);
    dio.options.receiveTimeout = const Duration(minutes: 10);
    
    print('Starting download from URL: $trimmed');
    print('Target file path: $filePath');
    
    try {
      await dio.download(
        trimmed,
        filePath,
        onReceiveProgress: (received, total) {
          if (total != -1) {
            final progress = (received / total * 100).toStringAsFixed(2);
            print('Download progress for ${filename}: $progress% ($received/$total bytes)');
            if (onProgress != null) {
              onProgress(received, total);
            }
          }
        },
      );
      
      // Verify file was downloaded
      final downloadedFile = File(filePath);
      if (await downloadedFile.exists()) {
        final size = await downloadedFile.length();
        print('Download completed successfully: $filePath (${size} bytes)');
        return filePath;
      } else {
        throw Exception('Download completed but file does not exist at $filePath');
      }
    } catch (e) {
      print('Error downloading file from $trimmed: $e');
      // Clean up partial file if it exists
      final partialFile = File(filePath);
      if (await partialFile.exists()) {
        try {
          await partialFile.delete();
          print('Deleted partial file: $filePath');
        } catch (deleteError) {
          print('Error deleting partial file: $deleteError');
        }
      }
      rethrow;
    }
  }

  String _extractFilename(String url, {String? mediaType}) {
    String decodedUrl = Uri.decodeFull(url);
    String filename = decodedUrl.split('/').last.split('?').first;
    if (mediaType != null) {
      switch (mediaType) {
        case 'audio/mpeg':
          filename += '.mp3';
          break;
        case 'audio/mp4':
          filename += '.m4a';
          break;
        case 'video/mp4':
          filename += '.mp4';
          break;
        case 'image/jpeg':
        case 'image/png':
        case 'image/gif':
          filename += '.jpg';
          break;
        default:
          break;
      }
    } else {
      if (url.contains('images')) {
        filename += '.jpg';
      }
    }
    return filename;
  }

  Future<Directory?> _getDirectory() async {
    if (Platform.isAndroid || Platform.isIOS) {
      return await getApplicationDocumentsDirectory();
    } else if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      try {
        return await getDownloadsDirectory() ??
            await getApplicationDocumentsDirectory();
      } catch (e) {
        print(
            'Error getting downloads directory, falling back to applicationDocumentsDirectory: $e');
        return await getApplicationDocumentsDirectory();
      }
    }
    return null;
  }

  bool isNestedCampaignMediaItem(MediaItem media) {
    final type = (media.mediaType ?? '').toLowerCase();
    return type == 'campaign' ||
        (media.zones != null && media.zones!.isNotEmpty);
  }

  List<MediaItem> collectCampaignMediaItemsForDownload(
      List<Campaign> campaigns) {
    final result = <MediaItem>[];

    void visitZones(List<CampaignZone> zones) {
      for (final zone in zones) {
        final items = zone.mediaItems ?? const <MediaItem>[];
        for (final media in items) {
          if (isNestedCampaignMediaItem(media)) {
            visitZones(media.zones ?? const <CampaignZone>[]);
            continue;
          }
          final url = media.mediaUrl;
          if (url != null && url.isNotEmpty) {
            result.add(media);
          }
        }
      }
    }

    for (final c in campaigns) {
      visitZones(c.zones ?? const <CampaignZone>[]);
    }
    return result;
  }
}
