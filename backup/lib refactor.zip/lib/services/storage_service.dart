import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  Future<void> saveJsonObject(Map<String, dynamic> jsonObj) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('jsonObj', jsonEncode(jsonObj));
  }

  Future<Map<String, dynamic>?> loadJsonObject() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? jsonString = prefs.getString('jsonObj');
    if (jsonString != null) {
      return jsonDecode(jsonString);
    }
    return null;
  }

  Future<void> saveStoredState(bool state) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('storeState', state);
  }

  Future<bool?> getStoredState() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('storeState');
  }

  Future<void> saveApiResponse(Map<String, dynamic> response) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('apiResponse', jsonEncode(response));
  }

  Future<Map<String, dynamic>?> retrieveStoredResponse() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? jsonString = prefs.getString('apiResponse');
    if (jsonString != null) {
      return jsonDecode(jsonString) as Map<String, dynamic>;
    }
    return null;
  }

  Future<void> saveDeviceInfoMap(Map<String, dynamic> deviceInfo) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('deviceInfoMap', jsonEncode(deviceInfo));
  }

  Future<Map<String, dynamic>?> loadDeviceInfoFromSharedPreferences() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? jsonString = prefs.getString('deviceInfoMap');
    prefs.clear();
    if (jsonString != null) {
      return Map<String, dynamic>.from(jsonDecode(jsonString));
    }
    return null;
  }

  Future<void> clearAll() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  Future<void> saveLastPublishCampaignPayload(String payload) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('last_publish_campaign_payload', payload);
  }

  Future<String?> getLastPublishCampaignPayload() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('last_publish_campaign_payload');
  }
}
