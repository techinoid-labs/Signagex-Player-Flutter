import 'dart:io';

import 'package:flutter/material.dart';

import 'package:video_player/video_player.dart';

class VideoPlayerWidget extends StatefulWidget {
  final String filePath;
  final VoidCallback onVideoEnd;
  final String transitionType;
  final double volume;

  const VideoPlayerWidget({
    super.key,
    required this.filePath,
    required this.onVideoEnd,
    required this.transitionType,
    this.volume = 1.0,
  });

  @override
  State<VideoPlayerWidget> createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _controller;
  bool _isLoading = true;
  bool _isVideoEnded = false;

  @override
  void initState() {
    super.initState();
    _initializeVideo();
  }

  void _initializeVideo() async {
    print("[LOG] VideoPlayerWidget: Initializing video: ${widget.filePath}");

    final file = File(widget.filePath);
    if (!await file.exists()) {
      print(
          "[LOG] VideoPlayerWidget: ERROR - File does not exist: ${widget.filePath}");
      setState(() {
        _isLoading = false;
      });
      return;
    }

    print("[LOG] VideoPlayerWidget: File exists, creating controller...");
    _controller = VideoPlayerController.file(file)
      ..initialize().then((_) {
        print("[LOG] VideoPlayerWidget: Video initialized successfully");
        print(
            "[LOG] VideoPlayerWidget: Duration: ${_controller.value.duration}");
        print("[LOG] VideoPlayerWidget: Size: ${_controller.value.size}");

        if (!_controller.value.isInitialized) {
          print(
              "[LOG] VideoPlayerWidget: ERROR - Controller not initialized after initialize()");
          setState(() {
            _isLoading = false;
          });
          return;
        }

        setState(() {
          _isLoading = false;
          _controller.setVolume(widget.volume.clamp(0.0, 1.0));
          _controller.setLooping(true);
          _controller.play();
          print("[LOG] VideoPlayerWidget: Video play() called");
        });

        Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted) {
            print(
                "[LOG] VideoPlayerWidget: After 500ms - IsPlaying: ${_controller.value.isPlaying}, "
                "HasError: ${_controller.value.hasError}");
            if (_controller.value.hasError) {
              print(
                  "[LOG] VideoPlayerWidget: ERROR after play() - ${_controller.value.errorDescription}");
            }
            if (!_controller.value.isPlaying &&
                _controller.value.isInitialized) {
              print(
                  "[LOG] VideoPlayerWidget: WARNING - Video not playing after play() call, trying again...");
              _controller.play();
            }
          }
        });

        _controller.addListener(() {
          if (!_controller.value.isLooping &&
              _controller.value.position >= _controller.value.duration &&
              !_isVideoEnded) {
            _isVideoEnded = true;
            widget.onVideoEnd();
          }

          if (_controller.value.position.inSeconds % 5 == 0 &&
              _controller.value.position.inMilliseconds > 0) {
            print(
                "[LOG] VideoPlayerWidget: Playing - Position: ${_controller.value.position}, "
                "IsPlaying: ${_controller.value.isPlaying}");
            if (_controller.value.hasError) {
              print(
                  "[LOG] VideoPlayerWidget: ERROR - ${_controller.value.errorDescription}");
            }
          }
        });
      }).catchError((error, stackTrace) {
        print("[LOG] VideoPlayerWidget: ERROR initializing video: $error");
        print("[LOG] VideoPlayerWidget: Stack trace: $stackTrace");
        print("[LOG] VideoPlayerWidget: File path: ${widget.filePath}");
        setState(() {
          _isLoading = false;
        });
      });
  }

  void _checkVideoEnd() {
    if (_controller.value.isInitialized &&
        !_controller.value.isPlaying &&
        _controller.value.position >= _controller.value.duration &&
        !_isVideoEnded) {
      setState(() {
        _isVideoEnded = true;
      });
      widget.onVideoEnd();
    }
  }

  @override
  void didUpdateWidget(covariant VideoPlayerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.filePath != widget.filePath) {
      _controller.removeListener(_checkVideoEnd);
      _controller.dispose();
      _initializeVideo();
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget videoWidget;

    if (_isLoading) {
      videoWidget = const Center(child: CircularProgressIndicator());
    } else if (!_controller.value.isInitialized) {
      videoWidget = Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error, size: 48, color: Colors.red),
            const SizedBox(height: 16),
            const Text("Video not initialized", style: TextStyle(fontSize: 16)),
            Text("File: ${widget.filePath}",
                style: const TextStyle(fontSize: 12)),
            if (_controller.value.hasError)
              Text("Error: ${_controller.value.errorDescription}",
                  style: const TextStyle(fontSize: 12, color: Colors.red)),
          ],
        ),
      );
    } else {
      videoWidget = SizedBox.expand(
        child: VideoPlayer(_controller),
      );
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: videoWidget,
    );
  }

  @override
  void dispose() {
    _controller.removeListener(_checkVideoEnd);
    _controller.dispose();
    super.dispose();
  }
}
