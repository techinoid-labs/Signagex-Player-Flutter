import 'package:flutter/material.dart';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class SvgWidget extends StatefulWidget {
  final String svgContent;
  final VoidCallback onSvgEnd;
  final String transitionType;

  const SvgWidget({
    super.key,
    required this.svgContent,
    required this.onSvgEnd,
    required this.transitionType,
  });

  @override
  State<SvgWidget> createState() => _SvgWidgetState();
}

class _SvgWidgetState extends State<SvgWidget> {
  InAppWebViewController? _webViewController;
  double progress = 0;

  @override
  void dispose() {
    _webViewController?.dispose();
    super.dispose();
  }

  String _createSvgHtml(String svgContent) {
    return '''
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    html, body {
      width: 100%;
      height: 100%;
      overflow: hidden;
      background: transparent;
    }
    body {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    svg {
      width: 100%;
      height: 100%;
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }
  </style>
</head>
<body>
  $svgContent
</body>
</html>
''';
  }

  @override
  Widget build(BuildContext context) {
    final htmlContent = _createSvgHtml(widget.svgContent);

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: Column(
        children: [
          if (progress < 1.0) LinearProgressIndicator(value: progress),
          Expanded(
            child: InAppWebView(
              initialData: InAppWebViewInitialData(
                data: htmlContent,
                mimeType: 'text/html',
                encoding: 'utf-8',
              ),
              initialSettings: InAppWebViewSettings(
                transparentBackground: true,
                useShouldOverrideUrlLoading: true,
                javaScriptEnabled: true,
                domStorageEnabled: true,
              ),
              onWebViewCreated: (InAppWebViewController controller) {
                _webViewController = controller;
              },
              onProgressChanged:
                  (InAppWebViewController controller, int newProgress) {
                setState(() {
                  progress = newProgress / 100.0;
                });
              },
              onLoadError: (InAppWebViewController controller, Uri? url,
                  int code, String message) {
                print("SVG load error: $message");
              },
              onLoadHttpError: (InAppWebViewController controller, Uri? url,
                  int statusCode, String description) {
                print("SVG HTTP error: $description");
              },
            ),
          ),
        ],
      ),
    );
  }
}
