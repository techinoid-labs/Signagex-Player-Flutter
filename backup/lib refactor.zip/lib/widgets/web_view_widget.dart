import 'package:flutter/material.dart';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class WBViewWidget extends StatefulWidget {
  final String media;
  final VoidCallback onMediaEnd;

  const WBViewWidget({
    super.key,
    required this.media,
    required this.onMediaEnd,
  });

  @override
  State<WBViewWidget> createState() => _WBViewWidgetState();
}

class _WBViewWidgetState extends State<WBViewWidget> {
  InAppWebViewController? _webViewController;
  double progress = 0;

  @override
  void dispose() {
    _webViewController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String fileUrl = 'file://${widget.media}';

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: Column(
        children: [
          if (progress < 1.0) LinearProgressIndicator(value: progress),
          Expanded(
            child: InAppWebView(
              initialUrlRequest:
                  URLRequest(url: WebUri.uri(Uri.parse(fileUrl))),
              onWebViewCreated: (InAppWebViewController controller) {
                _webViewController = controller;
              },
              onProgressChanged: (controller, newProgress) {
                setState(() {
                  progress = newProgress / 100.0;
                });
              },
              onLoadError: (controller, url, code, message) {
                print("Load error: $message");
              },
              onLoadHttpError: (controller, url, statusCode, description) {
                print("HTTP error: $description");
              },
            ),
          ),
        ],
      ),
    );
  }
}
