import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import 'package:digital_signage/models/compaign_model.dart';

import '../utils/media_type_utils.dart';
import '../utils/transition_utils.dart';
import '../view_models/mqtt_view_model.dart';

import 'image_widget.dart';
import 'svg_widget.dart';
import 'video_player_widget.dart';
import 'web_view_widget.dart';

class VideoPlaylistWidget extends StatefulWidget {
  final String zoneId;
  final List<MediaItem> mediaItems;
  final bool campaignCanPlay;
  final CampaignSchedule? campaignSchedule;
  final double coordinateBaseWidth;
  final double coordinateBaseHeight;

  const VideoPlaylistWidget({
    super.key,
    required this.zoneId,
    required this.mediaItems,
    required this.campaignCanPlay,
    required this.campaignSchedule,
    required this.coordinateBaseWidth,
    required this.coordinateBaseHeight,
  });

  @override
  State<VideoPlaylistWidget> createState() => _VideoPlaylistWidgetState();
}

class _VideoPlaylistWidgetState extends State<VideoPlaylistWidget> {
  int _currentMediaIndex = 0;
  Timer? _timer;
  Timer? _restrictionCheckTimer;
  double _opacity = 1.0;
  VideoPlayerController? _videoController;
  DateTime? _videoStartTime;
  int? _targetDuration;
  bool _isDisposed = false;

  @override
  void initState() {
    super.initState();
    _timer = Timer(Duration.zero, () {});
    _startRestrictionCheckTimer();
    _initializeNextMedia();
  }

  void _startRestrictionCheckTimer() {
    _restrictionCheckTimer?.cancel();
    _restrictionCheckTimer =
        Timer.periodic(const Duration(seconds: 8), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      _checkCampaignRestrictions();
    });
  }

  void _checkCampaignRestrictions() {
    if (widget.campaignSchedule == null) return;

    final mqttViewModel = Provider.of<MqttViewModel>(context, listen: false);
    const String reset = '\x1B[0m';
    const String red = '\x1B[31m';
    const String yellow = '\x1B[33m';
    const String cyan = '\x1B[36m';

    bool canPlay = false;

    if (widget.campaignSchedule?.alwaysPlay ?? false) {
      canPlay = true;
    } else {
      final restrictions = widget.campaignSchedule?.restrictions;
      if (restrictions != null && restrictions.isNotEmpty) {
        canPlay = mqttViewModel.checkRestrictions(restrictions);
      } else {
        canPlay = false;
      }
    }

    if (!canPlay && widget.campaignCanPlay) {
      print(
          '$red🛑 PERIODIC CHECK: Campaign restrictions FAILED → Stopping media$reset');
      print(
          '$yellow⏸️  Media was playing but campaign restrictions no longer allow it$reset');
      _stopMedia();
    } else if (canPlay && !widget.campaignCanPlay) {
      print(
          '$cyan✅ PERIODIC CHECK: Campaign restrictions now PASS → Can resume media$reset');
    }
  }

  void _stopMedia() {
    _timer?.cancel();
    _videoController?.pause();
    _videoController?.removeListener(_checkVideoPlaybackDuration);
    setState(() {
      _opacity = 0.0;
    });
  }

  @override
  void didUpdateWidget(covariant VideoPlaylistWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.mediaItems != widget.mediaItems ||
        oldWidget.zoneId != widget.zoneId ||
        oldWidget.campaignCanPlay != widget.campaignCanPlay) {
      if (!widget.campaignCanPlay && oldWidget.campaignCanPlay) {
        print(
            '\x1B[31m🛑 Campaign restrictions changed - stopping media\x1B[0m');
      }
      _resetState();
    }
  }

  void _resetState() {
    _currentMediaIndex = 0;
    _timer?.cancel();
    _videoController?.removeListener(_checkVideoPlaybackDuration);
    _videoController?.dispose();
    _videoController = null;
    _videoStartTime = null;
    _targetDuration = null;
    setState(() {
      _opacity = 1.0;
    });
    _initializeNextMedia();
  }

  bool _isNestedCampaign(MediaItem media) {
    final type = (media.mediaType ?? '').toLowerCase();
    return (media.zones != null && media.zones!.isNotEmpty) ||
        type == 'campaign';
  }

  Widget _buildNestedZones(MediaItem media) {
    final zones = media.zones ?? const <CampaignZone>[];
    if (zones.isEmpty) {
      return Center(child: Text("Zone ${widget.zoneId}: No subzones."));
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final scaleX = constraints.maxWidth / widget.coordinateBaseWidth;
        final scaleY = constraints.maxHeight / widget.coordinateBaseHeight;

        return ClipRect(
          child: Stack(
            fit: StackFit.expand,
            children: zones.map((z) {
              final left = (z.x ?? 0) * scaleX;
              final top = (z.y ?? 0) * scaleY;
              final width = (z.width ?? 0) * scaleX;
              final height = (z.height ?? 0) * scaleY;

              return Positioned(
                left: left,
                top: top,
                width: width,
                height: height,
                child: VideoPlaylistWidget(
                  zoneId: '${widget.zoneId}.${z.id ?? 0}',
                  mediaItems: z.mediaItems ?? const <MediaItem>[],
                  campaignCanPlay: widget.campaignCanPlay,
                  campaignSchedule: widget.campaignSchedule,
                  coordinateBaseWidth: widget.coordinateBaseWidth,
                  coordinateBaseHeight: widget.coordinateBaseHeight,
                ),
              );
            }).toList(),
          ),
        );
      },
    );
  }

  void _initializeNextMedia() {
    if (widget.mediaItems.isEmpty) {
      print("Zone ${widget.zoneId}: No media items available.");
      return;
    }

    if (_currentMediaIndex < 0 ||
        _currentMediaIndex >= widget.mediaItems.length) {
      print(
          "Zone ${widget.zoneId}: Media index $_currentMediaIndex is out of bounds (0-${widget.mediaItems.length - 1}), resetting to 0");
      _currentMediaIndex = 0;
    }

    const String reset = '\x1B[0m';
    const String red = '\x1B[31m';
    const String green = '\x1B[32m';
    const String yellow = '\x1B[33m';
    const String blue = '\x1B[34m';
    const String magenta = '\x1B[35m';
    const String cyan = '\x1B[36m';

    MediaItem currentMedia = widget.mediaItems[_currentMediaIndex];

    print(
        '$magenta═══════════════════════════════════════════════════════════$reset');
    print('$magenta🎥 MEDIA RESTRICTION CHECK$reset');
    print(
        '$magenta═══════════════════════════════════════════════════════════$reset');
    print('$blue📍 Zone: ${widget.zoneId}$reset');
    print('$blue🎬 Media ID: ${currentMedia.id ?? "N/A"}$reset');
    print('$blue📁 Media URL: ${currentMedia.mediaUrl ?? "N/A"}$reset');
    print(
        '$cyan📊 Campaign can play: ${widget.campaignCanPlay ? "YES ✅" : "NO ❌"}$reset');

    if (!widget.campaignCanPlay) {
      print(
          '$red❌ MEDIA: Campaign restrictions FAILED → Media cannot play$reset');
      print('$red⏭️  MEDIA: Skipping media (campaign not allowed)$reset');
      print(
          '$magenta═══════════════════════════════════════════════════════════$reset');
      _onMediaEnd();
      return;
    }

    bool shouldPlay = false;
    final mqttViewModel = Provider.of<MqttViewModel>(context, listen: false);

    if (currentMedia.schedule?.alwaysPlay ?? false) {
      shouldPlay = true;
      print('$green✅ MEDIA: alwaysPlay = true → Media can play$reset');
    } else {
      final restrictions = currentMedia.schedule?.restrictions;
      if (restrictions != null && restrictions.isNotEmpty) {
        print(
            '$yellow🔍 MEDIA: Checking ${restrictions.length} restriction(s)...$reset');
        shouldPlay = mqttViewModel.checkRestrictions(restrictions);
        if (shouldPlay) {
          print('$green✅ MEDIA: Restrictions PASSED → Media can play$reset');
        } else {
          print('$red❌ MEDIA: Restrictions FAILED → Media cannot play$reset');
        }
      } else {
        print(
            '$yellow⚠️  MEDIA: No restrictions configured and alwaysPlay = false$reset');
        print('$red⏭️  MEDIA: Skipping media (no schedule configured)$reset');
        print(
            '$magenta═══════════════════════════════════════════════════════════$reset');
        _onMediaEnd();
        return;
      }
    }

    print(
        '$magenta═══════════════════════════════════════════════════════════$reset');

    if (shouldPlay) {
      int? durationInt = currentMedia.settings?.duration;
      String duration = (durationInt ?? 0).toString();
      print(
          '$green▶️  MEDIA: Loading and playing media (duration: $duration seconds)$reset');
      _startMediaLoop(duration);
      if (_isNestedCampaign(currentMedia)) {
        setState(() {});
        return;
      }
      _loadMedia(currentMedia);
    } else {
      print('$red⏭️  MEDIA: Skipping media (restrictions did not pass)$reset');
      _onMediaEnd();
    }
  }

  void _startMediaLoop(String duration) {
    print("Starting media loop for duration: $duration");
    int durationSeconds = int.tryParse(duration) ?? 10;

    _timer?.cancel();

    if (durationSeconds > 0) {
      _timer = Timer(Duration(seconds: durationSeconds), () {
        print(
            "[LOG] Media duration timer expired after $durationSeconds seconds");
        _onMediaEnd();
      });
    }
  }

  void _loadMedia(MediaItem nextMedia) {
    final mediaUrl = nextMedia.mediaUrl ?? '';
    print("[LOG] Loading media: $mediaUrl");
    if (mediaUrl.isEmpty) {
      print("[LOG] Media URL is empty, skipping");
      _onMediaEnd();
      return;
    }

    if (MediaTypeUtils.isVideoFile(mediaUrl)) {
      _initializeNextVideo(nextMedia);
    } else if (MediaTypeUtils.isWebFile(mediaUrl)) {
      if (_currentMediaIndex > 0 &&
          (widget.mediaItems[_currentMediaIndex - 1].mediaUrl ?? '') ==
              mediaUrl) {
        print("[LOG] Skipping recreation of the same WebView");
        return;
      }
      setState(() {});
    } else if (MediaTypeUtils.isSvgContent(mediaUrl)) {
      print("[LOG] Current media is SVG: ${nextMedia.mediaUrl}");
      setState(() {});
    } else {
      print("[LOG] Current media is an image: ${nextMedia.mediaUrl}");
      setState(() {});
    }
  }

  void _initializeNextVideo(MediaItem nextMedia) {
    final mediaUrl = nextMedia.mediaUrl ?? '';
    if (mediaUrl.isEmpty) {
      print("[LOG] Video URL is empty, skipping");
      _onMediaEnd();
      return;
    }
    print("[LOG] Initializing video: $mediaUrl");

    final volume = (nextMedia.settings?.volume ?? 100) / 100.0;
    print(
        "[LOG] Setting video volume to: $volume (${nextMedia.settings?.volume}%)");

    _videoController = VideoPlayerController.file(File(mediaUrl))
      ..initialize().then((_) {
        if (_videoController!.value.isInitialized) {
          int targetDuration = nextMedia.settings?.duration ??
              _videoController!.value.duration.inSeconds;
          int videoLength = _videoController!.value.duration.inSeconds;

          _targetDuration = targetDuration;
          _videoStartTime = DateTime.now();

          print("Target play duration: $targetDuration seconds");
          print("Video length: $videoLength seconds");

          setState(() {
            _videoController!.setVolume(volume.clamp(0.0, 1.0));
            _videoController!.play();

            if (targetDuration > 0 &&
                videoLength > 0 &&
                videoLength < targetDuration) {
              _videoController!.setLooping(true);
              print(
                  "[LOG] Video ($videoLength sec) is shorter than target duration ($targetDuration sec), will loop");
            } else {
              _videoController!.setLooping(false);
            }
          });

          if (targetDuration > 0) {
            _videoController!.addListener(_checkVideoPlaybackDuration);
          } else {
            _videoController!.addListener(() {
              if (_videoController!.value.position >=
                      _videoController!.value.duration &&
                  _videoController!.value.position.inMilliseconds > 0) {
                print("[LOG] Video ended naturally, transitioning");
                _videoController!.removeListener(() {});
                _onMediaEnd();
              }
            });
          }
        }
      }).catchError((error) {
        print("[LOG] Error initializing video: $error");
        print("[LOG] Video URL: ${nextMedia.mediaUrl}");
        setState(() {});
      });
  }

  void _checkVideoPlaybackDuration() {
    if (_videoController == null ||
        _videoStartTime == null ||
        _targetDuration == null) {
      return;
    }

    if (_timer?.isActive ?? false) {
      final elapsed = DateTime.now().difference(_videoStartTime!).inSeconds;
      if (elapsed >= _targetDuration! &&
          _videoController!.value.position >=
              _videoController!.value.duration) {
        print("[LOG] Video ended naturally before timer, transitioning early");
        _videoController!.removeListener(_checkVideoPlaybackDuration);
        _timer?.cancel();
        _videoController!.pause();
        _onMediaEnd();
      }
    }
  }

  void _onMediaEnd() {
    _timer?.cancel();

    if (_videoController != null) {
      _videoController!.removeListener(_checkVideoPlaybackDuration);
    }

    if (!_isDisposed && mounted) {
      _videoController?.pause();
      _videoController?.dispose();
      _videoController = null;
      _videoStartTime = null;
      _targetDuration = null;

      final currentIndex = _currentMediaIndex;
      final totalMedia = widget.mediaItems.length;
      print("[LOG] Media ended at index $currentIndex of $totalMedia");

      setState(() {
        _opacity = 0.0;
      });

      Future.delayed(const Duration(milliseconds: 500), () {
        if (!mounted || _isDisposed) return;

        if (widget.mediaItems.isEmpty) {
          print("[LOG] No media items available, cannot transition");
          return;
        }

        setState(() {
          if (_currentMediaIndex < widget.mediaItems.length - 1) {
            _currentMediaIndex++;
          } else {
            _currentMediaIndex = 0;
          }
          print(
              "[LOG] Transitioning to media index $_currentMediaIndex of ${widget.mediaItems.length}");

          if (_currentMediaIndex < widget.mediaItems.length) {
            print(
                "[LOG] Next media ID: ${widget.mediaItems[_currentMediaIndex].id ?? 'N/A'}");
            print(
                "[LOG] Next media URL: ${widget.mediaItems[_currentMediaIndex].mediaUrl ?? 'N/A'}");
          }

          _opacity = 1.0;
          _initializeNextMedia();
        });
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _restrictionCheckTimer?.cancel();
    _isDisposed = true;
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.mediaItems.isEmpty) {
      return Center(child: Text("Zone ${widget.zoneId}: No media items."));
    }

    if (_currentMediaIndex < 0 ||
        _currentMediaIndex >= widget.mediaItems.length) {
      _currentMediaIndex = 0;
    }

    MediaItem currentMedia = widget.mediaItems[_currentMediaIndex];
    return AnimatedOpacity(
      opacity: _opacity,
      duration: const Duration(milliseconds: 500),
      child: AnimatedSwitcher(
        key: ValueKey(currentMedia.id),
        duration: const Duration(milliseconds: 500),
        transitionBuilder: (child, animation) {
          return TransitionUtils.buildTransition(
            child,
            animation,
            currentMedia.settings?.transition ?? 'none',
          );
        },
        child: _isNestedCampaign(currentMedia)
            ? _buildNestedZones(currentMedia)
            : MediaTypeUtils.isVideoFile(currentMedia.mediaUrl ?? '')
                ? VideoPlayerWidget(
                    key: ValueKey(
                        '${currentMedia.id ?? ''}_$_currentMediaIndex'),
                    filePath: currentMedia.mediaUrl ?? '',
                    onVideoEnd: () {
                      if (!(_timer?.isActive ?? false)) {
                        print(
                            "[LOG] Video ended naturally, timer already expired or not set");
                        _onMediaEnd();
                      } else {
                        print(
                            "[LOG] Video ended naturally but timer is still active, waiting for timer");
                      }
                    },
                    transitionType: currentMedia.settings?.transition ?? 'none',
                    volume: (currentMedia.settings?.volume ?? 100) / 100.0,
                  )
                : MediaTypeUtils.isWebFile(currentMedia.mediaUrl ?? '')
                    ? WBViewWidget(
                        key: ValueKey(currentMedia.id ?? ''),
                        media: currentMedia.mediaUrl ?? '',
                        onMediaEnd: _onMediaEnd)
                    : MediaTypeUtils.isSvgContent(currentMedia.mediaUrl ?? '')
                        ? SvgWidget(
                            key: ValueKey(currentMedia.id ?? ''),
                            svgContent: MediaTypeUtils.decodeSvgContent(
                                currentMedia.mediaUrl ?? ''),
                            onSvgEnd: _onMediaEnd,
                            transitionType:
                                currentMedia.settings?.transition ?? 'none',
                          )
                        : ImageWidget(
                            key: ValueKey(currentMedia.id ?? ''),
                            filePath: currentMedia.mediaUrl ?? '',
                            onImageEnd: _onMediaEnd,
                            transitionType:
                                currentMedia.settings?.transition ?? 'none',
                          ),
      ),
    );
  }
}
