import 'dart:async';

import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import 'package:digital_signage/models/compaign_model.dart';

import '../view_models/mqtt_view_model.dart';
import '../views/no_content_view.dart';
import '../widgets/center_image_widget.dart';
import '../widgets/text_widget.dart';
import '../widgets/video_playlist_widget.dart';

class CampaignView extends StatefulWidget {
  const CampaignView({super.key});

  @override
  State<CampaignView> createState() => _CampaignViewState();
}

class _CampaignViewState extends State<CampaignView> {
  late FocusNode _focusNode;
  Timer? _restrictionCheckTimer;

  @override
  void initState() {
    super.initState();
    _focusNode = FocusNode();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final mqttViewModel = Provider.of<MqttViewModel>(context, listen: false);
      mqttViewModel.startPlaylistTimerForCampaign();
    });
    _restrictionCheckTimer =
        Timer.periodic(const Duration(seconds: 8), (timer) {
      if (mounted) {
        setState(() {});
      } else {
        timer.cancel();
      }
    });
  }

  @override
  void dispose() {
    _restrictionCheckTimer?.cancel();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mqttViewModel = Provider.of<MqttViewModel>(context);
    final campaignModel = mqttViewModel.campaignModel;

    if (campaignModel?.data?.playerCampaigns?.isEmpty ?? true) {
      return const NoContentView();
    }

    final campaign = campaignModel
        ?.data?.playerCampaigns?[mqttViewModel.currentIndexOfCapmaign];
    if (campaign == null) {
      return const NoContentView();
    }

    final campaignSchedule = campaign.campaignSchedule;

    const String reset = '\x1B[0m';
    const String red = '\x1B[31m';
    const String green = '\x1B[32m';
    const String yellow = '\x1B[33m';
    const String blue = '\x1B[34m';
    const String cyan = '\x1B[36m';

    print(
        '$cyan═══════════════════════════════════════════════════════════$reset');
    print('$cyan🎬 CAMPAIGN RESTRICTION CHECK$reset');
    print(
        '$cyan═══════════════════════════════════════════════════════════$reset');
    print('$blue📋 Campaign: ${campaign.campaignName ?? "N/A"}$reset');

    bool campaignCanPlay = false;

    if (campaignSchedule?.alwaysPlay ?? false) {
      campaignCanPlay = true;
      print('$green✅ CAMPAIGN: alwaysPlay = true → Campaign can play$reset');
    } else {
      final restrictions = campaignSchedule?.restrictions;
      if (restrictions != null && restrictions.isNotEmpty) {
        print(
            '$yellow🔍 CAMPAIGN: Checking ${restrictions.length} restriction(s)...$reset');
        campaignCanPlay = mqttViewModel.checkRestrictions(restrictions);
        if (campaignCanPlay) {
          print(
              '$green✅ CAMPAIGN: Restrictions PASSED → Campaign can play$reset');
        } else {
          print(
              '$red❌ CAMPAIGN: Restrictions FAILED → Campaign cannot play$reset');
        }
      } else {
        print('$yellow⚠️  CAMPAIGN: No restrictions configured$reset');
        campaignCanPlay = false;
      }
    }

    print(
        '$cyan═══════════════════════════════════════════════════════════$reset');

    if (campaignCanPlay) {
      return _buildZones(campaign, campaignCanPlay);
    } else {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Column(
          children: [
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomImageWidget(
                      imagePath: 'assets/images/Browser.png',
                    ),
                    SimpleText(
                      text: "Campaign Not Scheduled",
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                    SimpleText(
                      text: "Campaign is not scheduled to play at this time.",
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    }
  }

  Widget _buildZones(PlayerCampaign campaign, bool campaignCanPlay) {
    final screenSize = MediaQuery.of(context).size;
    final deviceWidth = screenSize.width;
    final deviceHeight = screenSize.height;

    final campaignWidth = campaign.resolution?.width?.toDouble() ?? deviceWidth;
    final campaignHeight =
        campaign.resolution?.height?.toDouble() ?? deviceHeight;

    final scaleX = deviceWidth / campaignWidth;
    final scaleY = deviceHeight / campaignHeight;

    print("Campaign resolution: ${campaignWidth}x${campaignHeight}");
    print("Device resolution: ${deviceWidth}x${deviceHeight}");
    print("Scale factors: X=$scaleX, Y=$scaleY");

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: (details) {
          final mqttViewModel =
              Provider.of<MqttViewModel>(context, listen: false);
          mqttViewModel.setTapPosition(
              details.localPosition.dx, details.localPosition.dy);
          print(
              "Tapped at: x=${details.localPosition.dx}, y=${details.localPosition.dy}");
        },
        child: Stack(
          children: (campaign.zones ?? []).map((zone) {
            final scaledX = (zone.x ?? 0) * scaleX;
            final scaledY = (zone.y ?? 0) * scaleY;
            final scaledWidth = (zone.width ?? 0) * scaleX;
            final scaledHeight = (zone.height ?? 0) * scaleY;

            return Positioned(
              left: scaledX,
              top: scaledY,
              width: scaledWidth,
              height: scaledHeight,
              child: VideoPlaylistWidget(
                zoneId: (zone.id ?? 0).toString(),
                mediaItems: zone.mediaItems ?? [],
                campaignCanPlay: campaignCanPlay,
                campaignSchedule: campaign.campaignSchedule,
                coordinateBaseWidth: campaignWidth,
                coordinateBaseHeight: campaignHeight,
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
