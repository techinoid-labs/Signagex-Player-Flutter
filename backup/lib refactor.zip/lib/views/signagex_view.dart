import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';

import 'package:digital_signage/view_models/mqtt_view_model.dart';

class SignagexView extends StatefulWidget {
  const SignagexView({super.key});

  @override
  State<SignagexView> createState() => _SignagexViewState();
}

class _SignagexViewState extends State<SignagexView> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final urlLauncherViewModel =
        Provider.of<MqttViewModel>(context, listen: false);
    final pairingCode = urlLauncherViewModel.topic;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(
                    "assets/images/Logo.png",
                    height: 300,
                    width: 300,
                  ),
                ],
              ),
              const SizedBox(height: 20),
              if (pairingCode.isNotEmpty)
                QrImageView(
                  data: pairingCode,
                  version: QrVersions.auto,
                  size: screenWidth * 0.1,
                  backgroundColor: Colors.white,
                  eyeStyle: const QrEyeStyle(
                    eyeShape: QrEyeShape.square,
                    color: Colors.black,
                  ),
                  dataModuleStyle: const QrDataModuleStyle(
                    dataModuleShape: QrDataModuleShape.square,
                    color: Colors.black,
                  ),
                ),
              const SizedBox(height: 20),
              if (pairingCode.isNotEmpty)
                Text(
                  pairingCode,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 64,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 8,
                  ),
                ),
              const SizedBox(height: 40),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.15),
                child: const Text(
                  "To get started, scan the QR code above or enter the pairing code on your device. This will connect your screen to your account and enable content management.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    height: 1.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
