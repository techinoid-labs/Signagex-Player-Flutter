import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import 'package:digital_signage/models/play_list_model.dart';
import 'package:digital_signage/view_models/mqtt_view_model.dart';

class PlaylistScreen extends StatelessWidget {
  const PlaylistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final mqttViewModel = Provider.of<MqttViewModel>(context);

    return Scaffold(
      body: mqttViewModel.mediaPath.isNotEmpty
          ? VideoPlaylistWidget(
              mediaPaths: mqttViewModel.playListModel!.data.playlist.media,
              playlist: mqttViewModel.playListModel!.data.playlist,
            )
          : const Center(
              child: Text("No media available"),
            ),
    );
  }
}

class VideoPlaylistWidget extends StatefulWidget {
  final List<Media> mediaPaths;
  final Playlist playlist;

  VideoPlaylistWidget({super.key, required this.mediaPaths, required this.playlist});

  @override
  _VideoPlaylistWidgetState createState() => _VideoPlaylistWidgetState();
}

class _VideoPlaylistWidgetState extends State<VideoPlaylistWidget> {
  int _currentIndex = 0;
  late Timer _timer;
  double _opacity = 1.0;
  VideoPlayerController? _nextController;

  @override
  void initState() {
    super.initState();
    _initializeNextMedia();
  }

  void _onMediaEnd() {
    setState(() {
      _opacity = 0.0;
    });

    Future.delayed(const Duration(milliseconds: 500), () {
      setState(() {
        if (_currentIndex < widget.mediaPaths.length - 1) {
          _currentIndex++;
        } else {
          _currentIndex = 0;
        }
        _opacity = 1.0;
        _initializeNextMedia();
      });
    });
  }

  void _initializeNextMedia() {
    if (_currentIndex < widget.mediaPaths.length) {
      Media nextMedia = widget.mediaPaths[_currentIndex];

      // Debugging: Print media info
      print("Loading media at index $_currentIndex: ${nextMedia.mediaUrl!}");

      // Handle duration, fall back to default if null
      String duration = widget.playlist.playlistDefault.duration ?? nextMedia.settings?.duration ?? '10'; // Default to 10 seconds
      _startMediaLoop(duration);

      if (isVideoFile(nextMedia.mediaUrl!)) {
        _initializeNextVideo(nextMedia);
      } else {
        print("Current media is an image: ${nextMedia.mediaUrl!}");
      }
    }
  }

  void _initializeNextVideo(Media nextMedia) {
    _nextController = VideoPlayerController.file(File(nextMedia.mediaUrl!))
      ..initialize().then((_) {
        setState(() {
          _nextController!.play();
          _nextController!.setLooping(false);
        });
        _nextController!.addListener(() {
          _checkVideoDuration(nextMedia);
        });
      }).catchError((error) {
        print("Error initializing video: $error");
        setState(() {}); // Refresh UI to show fallback
      });
  }

  void _startMediaLoop(String duration) {
    int durationSeconds = int.tryParse(duration) ?? 10; // Default to 10 seconds if parsing fails
    _timer = Timer(Duration(seconds: durationSeconds), _onMediaEnd);
  }

  void _checkVideoDuration(Media media) {
    if (_nextController != null &&
        _nextController!.value.isInitialized &&
        !_nextController!.value.isPlaying &&
        _nextController!.value.position >= _nextController!.value.duration) {
      _nextController!.seekTo(Duration.zero);
      _nextController!.play();
    }
  }

  @override
  void dispose() {
    _timer.cancel();
    _nextController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Media currentMedia = widget.mediaPaths[_currentIndex];

    // Debugging: Display media information
    print("Displaying media: ${currentMedia.mediaUrl!}");

    return AnimatedOpacity(
      opacity: _opacity,
      duration: const Duration(milliseconds: 500), // Fade transition duration
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 500), // Animation duration for transition
        child: isVideoFile(currentMedia.mediaUrl!)
            ? VideoPlayerWidget(
                filePath: currentMedia.mediaUrl!,
                onVideoEnd: _onMediaEnd,
                aspectRatio: getAspectRatio(currentMedia.settings?.ratio),
                transitionType: widget.playlist.playlistDefault.transition ?? currentMedia.settings?.transition ?? 'fadeIn', // Default to fadeIn
              )
            : ImageWidget(
                filePath: currentMedia.mediaUrl!,
                onImageEnd: _onMediaEnd,
                aspectRatio: getAspectRatio(currentMedia.settings?.ratio),
                transitionType: widget.playlist.playlistDefault.transition ?? currentMedia.settings?.transition ?? 'fadeIn', // Default to fadeIn
              ),
      ),
    );
  }

  double getAspectRatio(String? ratio) {
    switch (ratio) {
      case 'Stretch to Fill Region':
        return 16 / 9; // Example: 16:9
      default:
        return 16 / 9; // Default to 16:9
    }
  }

  bool isVideoFile(String path) {
    final videoExtensions = ['.mp4', '.avi', '.mov', '.mkv'];
    return videoExtensions.any((ext) => path.endsWith(ext));
  }
}

class VideoPlayerWidget extends StatefulWidget {
  final String filePath;
  final VoidCallback onVideoEnd;
  final double aspectRatio;
  final String transitionType;

  const VideoPlayerWidget({
    super.key, 
    required this.filePath,
    required this.onVideoEnd,
    required this.aspectRatio,
    required this.transitionType,
  });

  @override
  _VideoPlayerWidgetState createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> with SingleTickerProviderStateMixin {
  late VideoPlayerController _controller;
  bool _isLoading = true;
  bool _isVideoEnded = false;

  @override
  void initState() {
    super.initState();
    _initializeVideo();
  }

  void _initializeVideo() async {
    _controller = VideoPlayerController.file(File(widget.filePath));

    try {
      await _controller.initialize();
      setState(() {
        _isLoading = false;
      });
      _controller.play();
      _controller.setLooping(false);
      _controller.addListener(_checkVideoEnd);
    } catch (error) {
      setState(() {
        _isLoading = false;
      });
      print("Error initializing video: $error");
    }
  }

  void _checkVideoEnd() {
    if (_controller.value.isInitialized &&
        !_controller.value.isPlaying &&
        _controller.value.position >= _controller.value.duration &&
        !_isVideoEnded) {
      setState(() {
        _isVideoEnded = true;
      });
      widget.onVideoEnd(); // Notify the parent to change the video
    }
  }

  @override
  void didUpdateWidget(covariant VideoPlayerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.filePath != widget.filePath) {
      _controller.removeListener(_checkVideoEnd);
      _controller.dispose();
      _initializeVideo();
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget videoWidget = _isLoading
        ? const Center(child: CircularProgressIndicator())
        : AspectRatio(
            aspectRatio: widget.aspectRatio,
            child: VideoPlayer(_controller),
          );

    if (!_isLoading && !_controller.value.isInitialized) {
      videoWidget = const Center(child: Text("Video failed to load"));
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: videoWidget,
    );
  }

  @override
  void dispose() {
    _controller.removeListener(_checkVideoEnd);
    _controller.dispose();
    super.dispose();
  }
}

class ImageWidget extends StatelessWidget {
  final String filePath;
  final VoidCallback onImageEnd;
  final double aspectRatio;
  final String transitionType;

  const ImageWidget({
    super.key,
    required this.filePath,
    required this.onImageEnd,
    required this.aspectRatio,
    required this.transitionType,
  });

  @override
  Widget build(BuildContext context) {
    Widget imageWidget = AspectRatio(
      aspectRatio: aspectRatio,
      child: Image.file(File(filePath), fit: BoxFit.cover),
    );

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: imageWidget,
    );
  }
}
