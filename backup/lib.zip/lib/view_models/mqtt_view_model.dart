import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:battery_plus/battery_plus.dart';
import 'package:dio/dio.dart';
// import 'package:battery_plus/battery_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:screen_brightness/screen_brightness.dart';
import 'package:system_info2/system_info2.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:digital_signage/models/play_list_model.dart';
import 'package:digital_signage/utils/globle_variable.dart';
import 'package:digital_signage/view_models/system_apply_settings_vm.dart';

import '../data/api_repository/api_repository.dart';
import '../services/mqtt_client_service.dart';
import '../utils/constants.dart';

enum MqttState {
  initial,
  success,
  failure,
  noContent,
  connectionScreen,
  noInternet,
  downloading,
  pairedScreen,
  playlistScreen
}

class MqttViewModel extends ChangeNotifier {
  final MqttClientService _mqttClientService;
  final DeviceSettingsViewModel deviceSettings = DeviceSettingsViewModel();

  MqttState _state = MqttState.initial;
  Map<String, dynamic> devicesinfo = deviceInfoMap;

  Map<String, dynamic>? _deviceInfo;
  List<dynamic> _mediaList = [];

  Map<String, dynamic>? get deviceInfo => _deviceInfo;
  static const _channel = MethodChannel('com.example/device_info');
  static const platform = MethodChannel('com.example/network');
  List<dynamic> get mediaList => _mediaList;
  MqttState get state => _state;
  String _topic = "";
  String get topic => _topic;

  PlayListModel? _playListModel;

  PlayListModel? get playListModel => _playListModel;

  Map<String, String?> macAddresses = {
    'wlan0': null,
    'eth0': null,
  };

  MqttViewModel(this._mqttClientService) {
    _mqttClientService.receivedMessageNotifier.addListener(_updateMessage);
    _mqttClientService.onMessageReceived = _handleIncomingMessage;
    fetchAllInfo();
    _initializeBasedOnPlatform();
    // _mqttConnection();
    _monitorConnectivity();
  }

  // Monitor connectivity changes and reinitialize MQTT on connection recovery
  void _monitorConnectivity() {
    InternetConnectionChecker().onStatusChange.listen((status) {
      final hasConnection = status == InternetConnectionStatus.connected;
      if (hasConnection) {
        _mqttConnection();
      } else {
        _state = MqttState.noInternet;
        notifyListeners();
      }
    });
  }

  Future<void> checkAndRequestPermissions() async {
    final status = await Permission.location.status;
    if (!status.isGranted) {
      await Permission.location.request();
    }
  }

  Future<void> fetchNetworkInfo() async {
    final NetworkInfo networkInfo = NetworkInfo();

    try {
      // Fetch network information
      final networkName = await networkInfo.getWifiName();
      final ipAddress = await networkInfo.getWifiIP();
      devicesinfo["last_ip_address"] = ipAddress;

      devicesinfo["network_name"] = networkName ?? "";

      print('Network Name (SSID): $networkName');
      print('IP Address: $ipAddress');
    } catch (e) {
      print('Failed to get network info: ${e.toString()}');
    }
  }

  Future<void> fetchBatteryInfo() async {
    final Battery battery = Battery();

    try {
      // Fetch battery information
      final batteryLevel = await battery.batteryLevel;
      print(batteryLevel);
    } catch (e) {
      print('Failed to get battery level: ${e.toString()}');
    }
  }

  String uniqueid = "";
  Future<String> getDeviceID() async {
    final result = await Process.run('powershell', [
      '-Command',
      'Get-WmiObject -Class Win32_ComputerSystemProduct | Select-Object -ExpandProperty UUID'
    ]);

    if (result.exitCode != 0) {
      return 'Error: ${result.stderr}';
    }

    return result.stdout.trim();
  }

  Future<void> fetchSystemInfo() async {
    try {
      // Common System Information
      final kernelArchitecture = SysInfo.kernelArchitecture.toString();
      print('Kernel Architecture: $kernelArchitecture');

      final kernelBitness = SysInfo.kernelBitness;
      print('Kernel Bitness: $kernelBitness');

      final kernelName = SysInfo.kernelName;
      print('Kernel Name: $kernelName');

      final kernelVersion = SysInfo.kernelVersion;
      print('Kernel Version: $kernelVersion');
      devicesinfo["android_version"] = kernelVersion;
      final operatingSystemName = SysInfo.operatingSystemName;
      print('Operating System Name: $operatingSystemName');

      final operatingSystemVersion = SysInfo.operatingSystemVersion;
      print('Operating System Version: $operatingSystemVersion');

      final userDirectory = SysInfo.userDirectory;
      print('User Directory: $userDirectory');

      final userId = SysInfo.userId;
      print('User ID: $userId');

      final userName = SysInfo.userName;
      print('User Name: $userName');

      final userSpaceBitness = SysInfo.userSpaceBitness;
      print('User Space Bitness: $userSpaceBitness');

      // Memory Information
      final totalPhysicalMemory = SysInfo.getTotalPhysicalMemory();
      print('Total Physical Memory: $totalPhysicalMemory bytes');

      final freePhysicalMemory = SysInfo.getFreePhysicalMemory();
      print('Free Physical Memory: $freePhysicalMemory bytes');

      final totalVirtualMemory = SysInfo.getTotalVirtualMemory();
      print('Total Virtual Memory: $totalVirtualMemory bytes');

      final freeVirtualMemory = SysInfo.getFreeVirtualMemory();
      print('Free Virtual Memory: $freeVirtualMemory bytes');
    } catch (e) {
      print("Failed to get system info: '${e.toString()}'.");
    }
  }

  Future<void> fetchAllInfo() async {
    await fetchNetworkInfo();
    await fetchBatteryInfo();
    await fetchSystemInfo();
  }

  Future<void> _initializeMacAddresses() async {
    final macAddressesMap = await getListOfMacAddresses();
    if (macAddressesMap != null) {
      final List<dynamic> macList = macAddressesMap['macAddress'];
      for (var item in macList) {
        final interface = item['interface'] as String?;
        final mac = item['mac'] as String?;
        if (interface != null && mac != null) {
          macAddresses[interface] = mac;
        }
      }

      print("Fetched MAC addresses: $macAddresses");
      devicesinfo["mac_address"]["macAddress"][0]["interface"] = "wlan0";
      devicesinfo["mac_address"]["macAddress"][1]["interface"] = "eth0";
      if (devicesinfo["mac_address"]["macAddress"][0]["interface"] == "wlan0") {
        devicesinfo["mac_address"]["macAddress"][0]["mac"] =
            macAddresses["wlan0"] ?? "";
      } else {
        devicesinfo["mac_address"]["macAddress"][1]["mac"] =
            macAddresses["eth0"] ?? "";
      }
      debugPrint("this is object$deviceInfoMap");
    } else {
      print("No MAC addresses found.");
    }
  }

  static Future<Map<String, dynamic>?> getListOfMacAddresses() async {
    final String? macAddressesJson =
        await platform.invokeMethod('getListOfMacAddresses');
    if (macAddressesJson != null) {
      return jsonDecode(macAddressesJson);
    }
    return null;
  }

  static Future<String?> getWifiMacAddress() async {
    return await _channel.invokeMethod('getWifiMacAddress');
  }

  static Future<String?> getEthernetMacAddress() async {
    return await _channel.invokeMethod('getEthernetMacAddress');
  }

  Future<void> _initializeBasedOnPlatform() async {
    if (Platform.isAndroid) {
      await _initializeMacAddresses();
      getDeviceInfoAndroid();
    } else if (Platform.isIOS) {
      final identifier =
          await _channel.invokeMethod<String>('getDeviceIdentifier');
      print('iOS Device Identifier: $identifier');
      devicesinfo["mac_address"]["platform"] = "IOS";
      devicesinfo["mac_address"]["macAddress"][0]["interface"] = "wlan0";
      if (devicesinfo["mac_address"]["macAddress"][0]["interface"] == "wlan0") {
        devicesinfo["mac_address"]["macAddress"][0]["mac"] = identifier;
      }
      getDeviceInfo();
    } else if (Platform.isMacOS) {
      await getDeviceIdentifiersForMac();
    } else if (Platform.isWindows) {
      await getSystemDataForWindows();
    } else if (Platform.isLinux) {
      await getDataForLinux();
    }
  }

  Future<void> getDeviceInfoAndroid() async {
    try {
      final String? result = await platform.invokeMethod('getSystemData');
      if (result != null) {
        print("Device Info from Android: $result");

        // Parse the JSON result
        final Map<String, dynamic> deviceInfo = jsonDecode(result);
        devicesinfo["device_info"] = deviceInfo;

        // Extract and parse the `cpu_detailed_information` field
        final cpuDetailedInfo =
            deviceInfo["cpu_detailed_information"] as String?;
        if (cpuDetailedInfo != null) {
          // Split the string by double newlines to separate processor blocks
          final processorBlocks = cpuDetailedInfo.trim().split('\n\n');

          final List<Map<String, String>> processorsList = [];

          for (var block in processorBlocks) {
            final lines = block.split('\n');
            final Map<String, String> processorMap = {};

            for (var line in lines) {
              final parts = line.split(':');
              if (parts.length == 2) {
                final key =
                    parts[0].trim().replaceAll(' ', '_').replaceAll('\t', '');
                final value = parts[1].trim();
                processorMap[key] = value;
              }
            }
            processorsList.add(processorMap);
          }

          // Update `cpu_detailed_information` in the device info map
          deviceInfo["cpu_detailed_information"] = processorsList;
        }

        debugPrint("this is ${deviceInfo["cpu_detailed_information"]}");
        devicesinfo["sender"] = "android";
        devicesinfo["android_version"] = deviceInfo["android_version"];
        devicesinfo["last_seen"] = deviceInfo["last_seen"];
        devicesinfo["device_model"] = deviceInfo["device_model"];
        devicesinfo["network_name"] = deviceInfo["network_name"];
        devicesinfo["time_zone"] = deviceInfo["time_zone"];
        devicesinfo["last_ip_address"] = deviceInfo["last_ip_address"];
        devicesinfo["cpu_information"]["processor"] =
            deviceInfo["cpu_information"]["processor"];
        devicesinfo["cpu_information"]["count_cores"] =
            deviceInfo["cpu_information"]["count_cores"];
        devicesinfo["memory_information"]["total_memory"] =
            int.parse(deviceInfo["memory_information"]["total_memory"]);
        devicesinfo["memory_information"]["available_memory"] =
            int.parse(deviceInfo["memory_information"]["available_memory"]);
        devicesinfo["memory_information"]["used_memory"] =
            int.parse(deviceInfo["memory_information"]["used_memory"]);
        devicesinfo["battery_information"]["battery_percentage"] = num.tryParse(
                deviceInfo["battery_information"]["battery_percentage"]
                        as String? ??
                    '') ??
            0;
        devicesinfo["battery_information"]["formatted_voltage"] = num.tryParse(
                deviceInfo["battery_information"]["formatted_voltage"]
                        as String? ??
                    '') ??
            0;

        devicesinfo["battery_information"]["formatted_temperature"] =
            num.tryParse(deviceInfo["battery_information"]
                        ["formatted_temperature"] as String? ??
                    '') ??
                0;
        devicesinfo["cpu_detailed_information"]["cpu_detailed_information"] =
            deviceInfo["cpu_detailed_information"];
        devicesinfo["hardware_details"] = deviceInfo["hardware_details"];
        devicesinfo["storage_info"]["total_storage"] =
            deviceInfo["storage_info"]["total_storage"];
        devicesinfo["storage_info"]["available_storage"] =
            deviceInfo["storage_info"]["available_storage"];
        devicesinfo["ram_info"] = deviceInfo["ram_info"];
        devicesinfo["device_resolution"]["width"] =
            deviceInfo["device_resolution"]["width"];
        devicesinfo["device_resolution"]["height"] =
            deviceInfo["device_resolution"]["height"];
        devicesinfo["camera_details"] =
            deviceInfo["camera_details"]["lens_facing"];
        debugPrint("this is full object$deviceInfoMap");
        _fetchCurrentLocation();
        notifyListeners();
      } else {
        print("Failed to get device info");
      }
    } on PlatformException catch (e) {
      print("Failed to get device info: '${e.message}'.");
    }
  }

  // Method to check and request location permissions
  Future<void> _getLocation() async {
    final status = await Permission.location.status;
    if (status.isGranted) {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      print(
          'location Latitude: ${position.latitude}, Longitude: ${position.longitude}');
    } else if (status.isDenied) {
      // Handle permission denied case
    } else if (status.isPermanentlyDenied) {
      // Handle permission permanently denied case
    }
  }

  // Method to fetch the current location
  Future<void> _fetchCurrentLocation() async {
    try {
      // Check and request location permissions
      await _getLocation();

      // Get the current position
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      // Update devicesinfo with latitude and longitude
      devicesinfo["latitude"] = position.latitude;
      devicesinfo["longitude"] = position.longitude;

      print('sadasdasasda$deviceInfoMap');
    } catch (e) {
      print('Error fetching location: $e');
    }
  }

  Future<void> getDeviceInfo() async {
    try {
      final Map<dynamic, dynamic>? result =
          await _channel.invokeMethod('getDeviceInfo');

      if (result != null) {
        print("this is result$result");
        _deviceInfo = Map<String, dynamic>.from(result);
        print('Device Info: $_deviceInfo');
        devicesinfo["sender"] = "ios";
        devicesinfo["android_version"] = _deviceInfo!["ios_version"];
        devicesinfo["storage_info"]["total_storage"] =
            _deviceInfo!["storage_info"]["total_storage"];
        devicesinfo["storage_info"]["available_storage"] =
            _deviceInfo!["storage_info"]["free_storage"];
        devicesinfo["cpu_information"]["count_cores"] =
            _deviceInfo!["cpu_information"]["processor_count"];
        devicesinfo["time_zone"] = _deviceInfo!["time_zone"];
        devicesinfo["battery_information"]["battery_percentage"] =
            _deviceInfo!["battery_information"]["battery_level"];
        devicesinfo["device_model"] = _deviceInfo!["name"];
        debugPrint("this is dzzata$deviceInfoMap");
        _fetchCurrentLocation();
      } else {
        _deviceInfo = null;
      }

      notifyListeners();
    } on PlatformException catch (e) {
      print("Failed to get device info: '${e.message}'.");
    }
  }

  double _screenWidth = 0;
  double _screenHeight = 0;

  double get screenWidth => _screenWidth;
  double get screenHeight => _screenHeight;

  void setScreenSize(double width, double height) {
    _screenWidth = width;
    _screenHeight = height;
    devicesinfo["device_resolution"] = "$_screenWidth x $screenHeight";

    notifyListeners();
  }

  Future<void> getSystemDataForWindows() async {
    try {
      final result = await getAllSystemInfo();
      if (result.exitCode == 0) {
        final output = result.stdout.trim();

        // Parse the JSON output from PowerShell
        final Map<String, dynamic> systemInfo = jsonDecode(output);
        devicesinfo["sender"] = "windows";
        devicesinfo["time_zone"] = systemInfo["TimeZone"];
        devicesinfo["mac_address"]["platform"] = "Windows";
        devicesinfo["mac_address"]["macAddress"][0]["interface"] = "wlan0";
        if (devicesinfo["mac_address"]["macAddress"][0]["interface"] ==
            "wlan0") {
          devicesinfo["mac_address"]["macAddress"][0]["mac"] =
              systemInfo["DeviceID"];
        }
        devicesinfo["ram_info"] = systemInfo["InstalledRAM"].toString();

        devicesinfo["hardware_details"]["model"] = systemInfo["DeviceName"];
        print(systemInfo["TimeZone"]);
        devicesinfo["hardware_details"]["device_id"] = systemInfo["DeviceID"];
        devicesinfo["storage_info"]["total_storage"] =
            systemInfo["Drives"][0]["TotalSpaceGB"].toString();

        devicesinfo["storage_info"]["available_storage"] =
            systemInfo["Drives"][0]["FreeSpaceGB"].toString();
        ;
        print(systemInfo["TimeZone"]);
        devicesinfo["hardware_details"]["ram"] = systemInfo["InstalledRAM"];
        devicesinfo["cpu_information"]["cpu_architecture"] =
            systemInfo["CPUArchitecture"];
        devicesinfo["cpu_information"]["processor"] = systemInfo["CPUInfo"];

        // Print all the system information
        systemInfo.forEach((key, value) {
          print('$key: $value');
        });

        _fetchCurrentLocation();
        await _checkPairingStatus();
      } else {
        print('Error: ${result.stderr}');
      }
    } catch (e) {
      print('An error occurred: $e');
    }
  }

  Future<ProcessResult> getAllSystemInfo() {
    return Process.run('powershell', [
      '-Command',
      '''
    # Get drive information
    \$drives = Get-WmiObject -Class Win32_LogicalDisk | ForEach-Object {
      [PSCustomObject]@{
        "DriveLetter" = \$_."DeviceID"
        "TotalSpaceGB" = [math]::round(\$_."Size" / 1GB, 2)
        "FreeSpaceGB" = [math]::round(\$_."FreeSpace" / 1GB, 2)
        "FileSystem" = \$_."FileSystem"
      }
    }

    # Get other system information
    \$info = @{
      "CPUInfo" = (Get-WmiObject -Class Win32_Processor | Select-Object -ExpandProperty Name);
      "CPUArchitecture" = (Get-WmiObject -Class Win32_Processor | Select-Object -ExpandProperty Architecture);
      "AvailableMemory" = (Get-CimInstance -ClassName Win32_OperatingSystem | Select-Object -ExpandProperty FreePhysicalMemory);
      "TimeZone" = (Get-TimeZone).Id;
      
      "DeviceName" = (Get-WmiObject -Class Win32_ComputerSystem | Select-Object -ExpandProperty Name);
      "InstalledRAM" = (Get-WmiObject -Class Win32_ComputerSystem | Select-Object -ExpandProperty TotalPhysicalMemory);
      "DeviceID" = (Get-WmiObject -Class Win32_ComputerSystemProduct | Select-Object -ExpandProperty UUID);
      "Drives" = \$drives
    }

    # Output the information as JSON
    \$info | ConvertTo-Json
    '''
    ]);
  }

  Future<void> getDataForLinux() async {
    try {
      final result = await getAllSystemInfoFLinux();
      if (result.exitCode == 0) {
        final output = result.stdout.trim();

        // Parse the JSON output
        final Map<String, dynamic> systemInfo = jsonDecode(output);

        devicesinfo["sender"] = "Linux";
        devicesinfo["time_zone"] = systemInfo["TimeZone"];
        devicesinfo["mac_address"]["platform"] = "Linux";
        devicesinfo["mac_address"]["macAddress"][0]["interface"] = "wlan0";
        if (devicesinfo["mac_address"]["macAddress"][0]["interface"] ==
            "wlan0") {
          devicesinfo["mac_address"]["macAddress"][0]["mac"] =
              systemInfo["MacAddress"];
        }
        devicesinfo["ram_info"] = systemInfo["InstalledRAM"].toString();

        devicesinfo["hardware_details"]["model"] = systemInfo["DeviceName"];
        print(systemInfo["TimeZone"]);
        devicesinfo["hardware_details"]["device_id"] = systemInfo["MacAddress"];
        devicesinfo["storage_info"]["total_storage"] =
            systemInfo["DiskCapacity"].toString();

        print(systemInfo["TimeZone"]);
        devicesinfo["hardware_details"]["ram"] = systemInfo["InstalledRAM"];
        devicesinfo["cpu_information"]["cpu_architecture"] =
            systemInfo["CPUArchitecture"];
        devicesinfo["cpu_information"]["processor"] = systemInfo["CPUInfo"];

        // Print all the system information
        systemInfo.forEach((key, value) {
          print('$key: $value');
        });

        _fetchCurrentLocation();
        await _checkPairingStatus();
      } else {
        print('Error: ${result.stderr}');
      }
    } catch (e) {
      print('An error occurred: $e');
    }
  }

  Future<String> getDeviceIDForLinux() async {
    final result =
        await Process.run('bash', ['-c', 'sudo dmidecode -s system-uuid']);

    if (result.exitCode != 0) {
      return 'Error: ${result.stderr}';
    }

    return result.stdout.trim();
  }

  Future<ProcessResult> getAllSystemInfoFLinux() {
    return Process.run('bash', [
      '-c',
      '''
    # Get system information
    mac_address=\$(ip addr show | grep 'link/ether' | awk '{print \$2}' | head -n 1)
    serial_number=\$(sudo dmidecode -s system-serial-number)
    os_version=\$(uname -r)
    cpu_info=\$(lscpu | grep 'Model name' | awk -F: '{print \$2}' | xargs)
    cpu_architecture=\$(uname -m)
    available_memory=\$(free -m | grep 'Mem:' | awk '{print \$7}')
    ram_info=\$(sudo dmidecode -t memory | grep -A16 'Memory Device' | grep -E 'Size|Manufacturer|Speed' | grep -v 'No Module Installed')
    network_adapters=\$(ip link show | awk -F: '/^[0-9]+:/{print \$2}' | xargs)
    time_zone=\$(timedatectl | grep 'Time zone' | awk '{print \$3}')
    device_name=\$(hostname)
    installed_ram=\$(free -m | grep 'Mem:' | awk '{print \$2}')
    product_id=\$(sudo dmidecode -s system-product-name)
    disk_capacity=\$(df -h --total | grep 'total' | awk '{print \$2}')

    # Create JSON structure including Disk Capacity
    info=\$(cat <<EOF
    {
      "MacAddress": "\$mac_address",
      "SerialNumber": "\$serial_number",
      "OSVersion": "\$os_version",
      "CPUInfo": "\$cpu_info",
      "CPUArchitecture": "\$cpu_architecture",
      "AvailableMemory": "\$available_memory MB",
      "RAMInfo": "\$ram_info",
      "NetworkAdapters": "\$network_adapters",
      "TimeZone": "\$time_zone",
      "DeviceName": "\$device_name",
      "InstalledRAM": "\$installed_ram MB",
      "ProductID": "\$product_id",
      "DiskCapacity": "\$disk_capacity"
    }
EOF
    )

    # Output JSON
    echo "\$info"
    '''
    ]);
  }

  Future<Map<String, dynamic>?> getDeviceIdentifiersForMac() async {
    try {
      const channel = MethodChannel('com.example/systemInfo');

      // Fetch all system info (as a Map)
      final Map<dynamic, dynamic>? systemInfo =
          await channel.invokeMethod('getSystemInfo');
      // final battery = Battery();
      // final batteryLevel = await battery.batteryLevel;
      // final batteryStatus = await battery.batteryState;
      // final batteryPlugged = await battery.onBatteryStateChanged;
      // print(
      //     "this is batterydata $batteryLevel....$batteryPlugged...$batteryStatus");
      if (systemInfo != null) {
        // devicesinfo["mac_address"]["platform"] = "iOS";
        // devicesinfo["battery_information"]["battery_percentage"] = batteryLevel;
        devicesinfo["mac_address"]["macAddress"][0]["interface"] = "wlan0";
        if (devicesinfo["mac_address"]["macAddress"][0]["interface"] ==
            "wlan0") {
          devicesinfo["mac_address"]["macAddress"][0]["mac"] =
              systemInfo["uuid"];
        }
        print("System Info: $systemInfo"); // Print all system information
        devicesinfo["android_version"] = systemInfo["os_version"];
        devicesinfo["platform"] = "macos";
        devicesinfo["device_resolution"] = systemInfo["device_resolution"];
        devicesinfo["time_zone"] = systemInfo["time_zone"];
        devicesinfo["cpu_information"] = systemInfo["cpu_information"];
        devicesinfo["memory_information"] = systemInfo["memory_information"];
        devicesinfo["storage_info"] = systemInfo["storage_info"];

        _fetchCurrentLocation();
        return Map<String, dynamic>.from(systemInfo);
      } else {
        print("Failed to retrieve system info.");
        return null;
      }
    } on PlatformException catch (e) {
      print("Failed to get device identifier: '${e.message}'.");
      return null;
    }
  }

  static Future<String?> getDeviceIdentifiers() async {
    try {
      final String? identifier =
          await _channel.invokeMethod('getDeviceIdentifier');
      print("Unique ID: $identifier");
      return identifier;
    } on PlatformException catch (e) {
      print("Failed to get device identifier: '${e.message}'.");
      return null;
    }
  }

  String get receivedMessage =>
      _mqttClientService.receivedMessageNotifier.value;

  Future<void> _mqttConnection() async {
    try {
      debugPrint("Attempting to reconnect to MQTT.");
      await _mqttClientService.connect();
      _state = MqttState.connectionScreen;
      notifyListeners();
      if (Platform.isAndroid || Platform.isIOS || Platform.isMacOS) {
        await _checkPairingStatus();
      }
    } catch (error) {
      _state = MqttState.noInternet;
      notifyListeners();
      debugPrint("Error during MQTT reinitialization: $error");
    }
  }

  double _progress = 0.0;
  bool _isDownloading = false;
  String _downloadedFilePath = '';

  double get progress => _progress;
  bool get isDownloading => _isDownloading;
  String get downloadedFilePath => _downloadedFilePath;

  // Future<void> downloadFile(String url) async {
  //   // Handle Android permissions
  //   if (Platform.isAndroid) {
  //     print('Requesting storage permission...');
  //     var status = await Permission.storage.request();
  //     if (!status.isGranted) {
  //       print('Storage permission denied');
  //       throw Exception('Storage permission not granted');
  //     }
  //     print('Storage permission granted');
  //   }

  //   _isDownloading = true;
  //   _progress = 0.0;
  //   _state = MqttState.downloading;
  //   notifyListeners();

  //   try {
  //     print('Starting download from URL: $url');

  //     // Extract filename from the URL
  //     String filename = _extractFilename(url);
  //     print('Extracted filename: $filename');

  //     // Get platform-specific directory
  //     Directory? directory = await _getDirectory();
  //     if (directory == null) {
  //       print('Unable to determine directory');
  //       throw Exception('Unable to determine directory');
  //     }
  //     print('Download directory: ${directory.path}');

  //     String filePath = '${directory.path}/$filename';

  //     // Initialize Dio for downloading
  //     Dio dio = Dio();

  //     // Start downloading the file
  //     await dio.download(
  //       url,
  //       filePath,
  //       onReceiveProgress: (received, total) {
  //         if (total != -1) {
  //           _progress = received / total;
  //           print('Download pogress: ${(_progress * 100).toStringAsFixed(2)}%');
  //           notifyListeners(); // Update progress in UI
  //         }
  //       },
  //     );

  //     _downloadedFilePath = filePath;
  //     print(
  //         'File downloaded to: $_downloadedFilePath'); // Print the file path for reference
  //     _state = MqttState.noContent;
  //   } catch (e) {
  //     _isDownloading = false;
  //     notifyListeners();
  //     print('Download failed: $e');
  //     throw Exception('Download failed: $e');
  //   }

  //   _isDownloading = false;
  //   notifyListeners();
  //   print('Download completed successfully.');
  // }

  // String _extractFilename(String url) {
  //   String decodedUrl = Uri.decodeFull(url);
  //   String filename = decodedUrl.split('/').last.split('?').first;
  //   return filename;
  // }

  // Future<Directory?> _getDirectory() async {
  //   if (Platform.isAndroid || Platform.isIOS) {
  //     return await getApplicationDocumentsDirectory();
  //   } else if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
  //     return await getDownloadsDirectory();
  //   }
  //   return null;
  // }
  int _downloadCount = 0; //
  double _overallProgress = 0.0; // Tracks total download progress (0.0 to 1.0)
  double get overallProgress => _overallProgress; // Getter for UI binding

  void _startDownloading() {
    if (_state == MqttState.downloading) {
      print("Downloads are already in progress.");
      return; // Prevent re-entering the download process
    }

    _downloadCount = _playListModel!
        .data.playlist.media.length; // Set the total count of media files
    print(
        "Total files ${_playListModel!.data.playlist.media.length} to download: $_downloadCount");

    if (_downloadCount > 0) {
      _state = MqttState
          .downloading; // Set state to downloading before starting downloads
      notifyListeners(); // Notify the UI that downloading has started
    } else {
      _state = MqttState.noContent; // If no files are available to download
      notifyListeners();
      return;
    }

    int completedDownloads = 0; // Track how many downloads have completed
    _overallProgress = 0.0; // Reset overall progress

    for (var media in _playListModel!.data.playlist.media) {
      String mediaUrl = media.mediaUrl??'';
      print("Starting download for Media URL: $mediaUrl");

      // Download each file and update the progress
      downloadFile(mediaUrl).then((_) {
        // Increment completed downloads
        completedDownloads++;
        print(
            "Downloaded file successfully. Completed: $completedDownloads / $_downloadCount");

        // Update overall progress
        _overallProgress = completedDownloads / _downloadCount;
        print(
            'Overall progress: ${(_overallProgress * 100).toStringAsFixed(2)}%');
        notifyListeners(); // Notify UI to update progress bar

        // Check if all downloads are complete
        if (completedDownloads == _downloadCount) {
          print("All files downloaded successfully.");
          _state = MqttState
              .playlistScreen; // All files downloaded, change to playlist screen state
          notifyListeners(); // Notify the UI to reflect state change

          // Optional: You can navigate to the playlist screen here
        }
      }).catchError((error) {
        print("Error downloading file: $error");
        _state = MqttState.failure; // On failure, set state to failure
        notifyListeners(); // Notify the UI
      });
    }
  }

  List<String> _mediaPath = [];
  List<String> get mediaPath => _mediaPath;

  Future<void> downloadFile(String url) async {
    // Handle Android permissions
    if (Platform.isAndroid) {
      print('Requesting storage permission...');
      var status = await Permission.storage.request();
      if (!status.isGranted) {
        print('Storage permission denied');
        throw Exception('Storage permission not granted');
      }
      print('Storage permission granted');
    }

    try {
      print('Starting download from URL: $url');

      // Extract filename from the URL
      String filename = _extractFilename(url);
      print('Extracted filename: $filename');

      // Get platform-specific directory
      Directory? directory = await _getDirectory();
      if (directory == null) {
        print('Unable to determine directory');
        throw Exception('Unable to determine directory');
      }
      print('Download directory: ${directory.path}');

      String filePath = '${directory.path}/$filename';

      // Initialize Dio for downloading
      Dio dio = Dio();

      // Start downloading the file
      await dio.download(
        url,
        filePath,
        onReceiveProgress: (received, total) {
          if (total != -1) {
            double progress = received / total;
            print('Download progress: ${(progress * 100).toStringAsFixed(2)}%');
            // Update progress in UI if necessary
          }
        },
      );
      _mediaPath.add(filePath);
      if (_playListModel != null &&
          _playListModel!.data.playlist.media.isNotEmpty) {
        // Iterate through the media list in playlist
        for (int i = 0; i < _playListModel!.data.playlist.media.length; i++) {
          // Access each media item
          var mediaItem = _playListModel!.data.playlist.media[i];

          // Check if there are enough file paths to assign
          if (i < _mediaPath.length) {
            // Assign the file path from _mediaPath to mediaUrl
            mediaItem.mediaUrl = _mediaPath[i];
          }
        }
      }

      print(
          'File downloaded to: $filePath'); // Print the file path for reference
    } catch (e) {
      print('Download failed: $e');
      throw Exception('Download failed: $e');
    }

    print('Download completed successfully.');
  }

String _extractFilename(String url, {String? mediaType}) {
  String decodedUrl = Uri.decodeFull(url);
  String filename = decodedUrl.split('/').last.split('?').first;

  // Determine the file extension based on the media type
  if (mediaType != null) {
    switch (mediaType) {
      case 'audio/mpeg':
        filename += '.mp3';
        break;
      case 'audio/mp4':
        filename += '.m4a';
        break;
      case 'video/mp4':
        filename += '.mp4';
        break;
      case 'image/jpeg':
      case 'image/png':
      case 'image/gif': // Add more image types as necessary
        filename += '.jpg'; // Defaulting to .jpg for general image URLs
        break;
      default:
        // Use the original filename if no match found
        break;
    }
  } else {
    // If no media type provided, assume it's an image
    if (url.contains('images')) {
      filename += '.jpg'; // Default to .jpg for image URLs
    }
  }

  return filename;
}

  Future<Directory?> _getDirectory() async {
    if (Platform.isAndroid || Platform.isIOS) {
      return await getApplicationDocumentsDirectory();
    } else if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      return await getDownloadsDirectory();
    }
    return null;
  }

  Future<void> _checkPairingStatus() async {
    Map<String, dynamic> requestBody;

    if (Platform.isAndroid) {
      requestBody = {
        "platform": "android",
        "macAddress": [
          {"mac": macAddresses['wlan0'], "interface": "wlan0"},
          {"mac": macAddresses['eth0'], "interface": "eth0"}
        ]
      };
    } else if (Platform.isIOS || Platform.isMacOS) {
      final uuid = Platform.isIOS
          ? await getDeviceIdentifiers() // Assuming this returns a String
          : (await getDeviceIdentifiersForMac())?[
              "uuid"]; // Extract "uuid" from the map

      requestBody = {"platform": "ios", "uuid": uuid ?? "unknown"};
      print(requestBody);
    } else if (Platform.isWindows) {
      requestBody = {"platform": "windows", "uuid": await getDeviceID()};
      print("windows$requestBody");
    } else if (Platform.isLinux) {
      requestBody = {"platform": "linux", "uuid": await getDeviceIDForLinux()};
      print("windows$requestBody");
    } else {
      debugPrint("Unsupported platform");

      return;
    }

    debugPrint("Request body: $requestBody");

    try {
      final response = await ApiRepository.sendPostRequest(
        requestBody,
        port,
        "player/connection/",
        null,
      );
      _topic = response["player_code"];
      debugPrint("This is the response from the$topic API: $response");
      globleTopic = _topic;
      subsibeMessage(topic);
      print(deviceInfoMap);
      publishMessage(globleTopic, jsonEncode(deviceInfoMap));

      if (response["paired"] == false) {
        _state = MqttState.pairedScreen;
      } else if (response["paired"] == true) {
        _state = MqttState.noContent;
        // downloadFile(
        //     "https://images2.alphacoders.com/597/thumb-1920-597309.jpg");

        // restartNetworkForAndroid();
      } else {
        _state = MqttState.failure;
      }
      notifyListeners();
    } catch (error) {
      _state = MqttState.failure;
      debugPrint("Error: $error");
    }

    notifyListeners();
  }

  Future<String> unmuteVolumeForMac() async {
    const MethodChannel _channel = MethodChannel('com.example/volumeControl');
    final String result = await _channel.invokeMethod('unmuteVolume');
    return result;
  }

  Future<String> restartNetworkForMac() async {
    const MethodChannel _channel = MethodChannel('com.example/networkControl');

    final String result = await _channel.invokeMethod('restartNetwork');
    return result;
  }

  Future<void> muteVolumeForAndroid() async {
    try {
      const platform = MethodChannel('com.example/network');

      final result = await platform.invokeMethod('muteVolume');
      print(
          result); // Prints "Volume muted" or the success message from Android
    } on PlatformException catch (e) {
      print("Failed to mute volume: '${e.message}'.");
    }
  }

  static Future<void> setOrientationForAndroid(int orientation) async {
    try {
      const MethodChannel _channel = MethodChannel('com.example/network');

      await _channel
          .invokeMethod('stOrientation', {'orientation': orientation});
    } on PlatformException catch (e) {
      print("Failed to set orientation: '${e.message}'.");
    }
  }

  Future<void> setBrightnessForMac(double brightness) async {
    try {
      const MethodChannel _channel =
          MethodChannel('com.example/brightnessControl');
      final String result = await _channel
          .invokeMethod('setBrightness', {'brightness': brightness});
      print("this is respone $result");
    } on PlatformException catch (e) {
      print("Failed to set brightness: '${e.message}'.");
    }
  }

  Future<void> setBrightnessForIOS(double value) async {
    const platform = MethodChannel('com.example/device_info');

    try {
      final result =
          await platform.invokeMethod('setScreenBrightness', {'value': value});
      print(result);
    } on PlatformException catch (e) {
      print("Failed to set brightness: '${e.message}'.");
    }
  }

  Future<void> restartNetworkForAndroid() async {
    try {
      final result = await platform.invokeMethod('restartNetwork');
      print(result); // Prints "Wi-Fi restarted" or success message from Android
    } on PlatformException catch (e) {
      print("Failed to restart Wi-Fi: '${e.message}'.");
    }
  }

  Future<void> setVolumeForIOS(double value) async {
    const platform = MethodChannel('com.example/device_info');

    try {
      final result = await platform.invokeMethod('setVolume', {'value': value});
      print(result);
    } on PlatformException catch (e) {
      print("Failed to set volume: '${e.message}'.");
    }
  }

  Future<void> setVolumeForAndroid(int level) async {
    const MethodChannel _channel = MethodChannel('com.example/network');

    await _channel.invokeMethod('setVolume', {'level': level});
  }

  Future<void> setAppBrightnessForANDROID(double brightness) async {
    try {
      double currentBrightnesss = await ScreenBrightness().current;

      // Log the current brightness to verify
      print('Current brightness is: $currentBrightnesss');
      // Log the brightness value before setting
      print('Attempting to set brightness to: $brightness');

      // Set the application screen brightness
      await ScreenBrightness().setScreenBrightness(brightness);

      // Get the current brightness after setting
      double currentBrightness = await ScreenBrightness().current;

      // Log the current brightness to verify
      print('Current brightness is: $currentBrightness');
    } catch (e) {
      // Handle any errors
      print('Failed to set brightness: $e');
    }
  }

  Future<void> setVolumeForMac(int volume) async {
    const platform = MethodChannel('com.example/volumeControl');
    try {
      await platform.invokeMethod('setVolume', {'volume': volume});
    } on PlatformException catch (e) {
      print("Failed to set volume: ${e.message}");
    }
  }

  Future<void> _muteVolumeForMac() async {
    const platform = MethodChannel('com.example/volumeControl');
    try {
      await platform.invokeMethod('muteVolume');
    } on PlatformException catch (e) {
      print("Failed to mute volume: ${e.message}");
    }
  }

  void subsibeMessage(String topic) {
    _mqttClientService.subscribe(topic);
  }

  void publishMessage(String topic, String message) {
    _mqttClientService.publish(topic, message);
  }

  void _handleIncomingMessage(String message) {
    // Handle the incoming message here
    print('Received message in ViewModel: $message');
    final jsonObj = jsonDecode(message);

    if (jsonObj["action"] == "action_reboot") {
      print("action rebooot");
      var data = {"success": true};
      // playlistViewModel.downloadFile("https://images2.alphacoders.com/597/thumb-1920-597309.jpg");
      publishMessage(globleTopic, jsonEncode(data));

      if (Platform.isMacOS) {
        deviceSettings.rebootDeviceForMacOS();
      } else if (Platform.isAndroid) {
        print("i am here for andorind");
        deviceSettings.rebootDeviceForAndroid();
      } else if (Platform.isWindows) {
        deviceSettings.rebootDeviceForWindows();
      } else if (Platform.isLinux) {
        deviceSettings.rebootDeviceForLinux();
      }
    } else if (jsonObj["action"] == "action_setup_player") {
      print("action mute${jsonObj["settings"]["mute_audio"]}");
      if (jsonObj["settings"]["mute_audio"] == true) {
        if (Platform.isMacOS) {
          deviceSettings.muteVolumeForMac();
        } else if (Platform.isAndroid) {
          print("i am here for andorind");
          deviceSettings.muteVolumeForAndroid();
        } else if (Platform.isWindows) {
          deviceSettings.muteVolumeForWindows();
        } else if (Platform.isLinux) {
          deviceSettings.muteVolumeForLinux();
        }
      } else if (jsonObj["settings"]["mute_audio"] == false) {
        if (Platform.isMacOS) {
          deviceSettings.unmuteVolumeForMac();
        } else if (Platform.isAndroid) {
          print("i am here for andorind");
          deviceSettings.unmuteVolumeForAndroid();
        } else if (Platform.isWindows) {
          deviceSettings.unmuteVolumeForWindows();
        } else if (Platform.isLinux) {
          deviceSettings.unmuteVolumeForLinux();
        }
      } else if (jsonObj["settings"]["brightness"]['value'] != null) {
        if (Platform.isMacOS) {
          print("No brightness For Mac");
          // deviceSettings.unmuteVolumeForMac();
        } else if (Platform.isAndroid) {
          print("i am here for andorind");
          var value = jsonObj["settings"]["brightness"]['value'];
          deviceSettings.setAppBrightnessForAndroid(value);
        } else if (Platform.isWindows) {
          var res = jsonObj["settings"]["brightness"]['value'];
          deviceSettings.adjustBrightnessForWindows(res);
        } else if (Platform.isLinux) {
          var res = jsonObj["settings"]["brightness"]['value'];
          deviceSettings.changeBrightnessForLinux(res);
        }
      }
      var data = {"success": true};
      publishMessage(globleTopic, jsonEncode(data));
    } else if (jsonObj["action"] == "publish_playlist") {
      print("i am in actionPlaylist${jsonObj["data"]["playlist"]["media"]}");
      // _mediaList = jsonObj;
      _playListModel = playListModelFromJson(jsonEncode(jsonObj));
      print("model data ${_playListModel!.data.playlist.media}");
      print(_mediaList);
      for (var media in _playListModel!.data.playlist.media) {
        // String mediaUrl = media["mediaUrl"];
        print("Media URL: $media");

        // Download the media file
        _startDownloading();
      }
    }
  }

  void _updateMessage() {
    notifyListeners();
  }

  Future<void> launchUrl(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
